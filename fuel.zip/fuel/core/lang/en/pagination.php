<?php

return array(
	'previous' => 'Previous',
	'next'     => 'Next',
);
