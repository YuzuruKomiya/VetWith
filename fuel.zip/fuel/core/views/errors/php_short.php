<strong><?php echo $type; ?>:</strong> <?php echo e($message); ?> in <?php echo $filepath, ' [', $line, ']: ', $function; ?>
