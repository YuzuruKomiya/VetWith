<p>
	<b><?php echo $c_email;?></b> あてにメールを送信しました。
</p>

