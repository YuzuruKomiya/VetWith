<div class="boxpaddingsmall">
	<?php echo $delete_message; ?>
</div>