<div class="bs-component">
	<div class="jumbotron">
		<h2>ようこそ、VetWith（ベットウィズ）へ！</h2>
		<p>VetWithは、獣医学生の採用を検討するすべての動物病院が使用できる、完全無料の病院・求人情報掲載ツールです。</p>
		<p>詳細な情報を入力し、いますぐ利用できるようにしましょう。</p>
		<p>
			<?php echo Html::anchor(Uri::base().'clinic/mypage/set_detail', '病院情報を入力する', array('class' => 'btn btn-primary btn-lg')); ?>
		</p>
	</div>
</div>