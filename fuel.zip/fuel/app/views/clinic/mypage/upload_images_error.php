<div class="boxpaddingsmall">
	<ul>
		<?php

		foreach ($upload_error as $value)
		{
			echo '<li>'.$value.'</li>';
		}
		?>
	</ul>
</div>