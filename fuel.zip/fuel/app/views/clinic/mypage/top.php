<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">
			<?php if (isset($hint_suggestion)): ?>
			<?php echo $hint_suggestion; ?>
			<?php endif;?>
		</div>
	</div>
</div>
