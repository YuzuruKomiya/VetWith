<div class="row">
	<div class="col-md-12">
		<div class="alert alert-warning" role="alert">
			<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
			お問い合わせありがとうございます。
		</div>
		<div class="boxpaddingsmall">
			<ul>
				<li>
					お問い合わせを送信しました。
				</li>
				<li>
					対応までに２～３日程度のお時間をいただく場合がございます。
				</li>
				<li>
					折り返しメールのドメインは「@gmail.com」から送信致します。
				</li>
			</ul>
		</div>
	</div>
</div>
