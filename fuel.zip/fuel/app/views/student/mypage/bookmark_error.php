<div class="boxpaddingsmall">
	<div class="alert alert-info">
		<p>
			現在登録されているブックマークはありません。新しい動物病院の求人を検索してみましょう。
		</p>
		<p>
			<?php echo Html::anchor(Uri::base().'offers/search', '求人を検索する', array('class' => 'btn btn-primary btn-lg')); ?>
		</p>
		
	</div>
</div>

