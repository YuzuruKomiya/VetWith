<p>
	<b><?php echo $s_email;?></b> あてにメールを送信しました。
</p>

