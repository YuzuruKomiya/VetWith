<div class="alert alert-warning" role="alert">
	運営情報についてです。
</div>
<div class="row">
	<div class="col-xs-12 col-md-10 col-md-offset-1 boxpaddingsmall">
		<div class="page-header" id="generalrule">
			<h2>
				最近の更新
			</h2>
		</div>
		<div class="boxpaddingsmall">
			<p class="text-right">
			最終更新：2015年8月24日
		</p>
			<p>
				特になし
			</p>
		</div>
		<div class="page-header" id="generalrule">
			<h2>
				運営元
			</h2>
		</div>
		<div class="boxpaddingsmall">
			<p>
				VetWithは獣医学課程在学中の大学生個人によって運営されております。
			</p>
			<p>
				ご意見、ご要望は<?php echo Html::anchor(Uri::base().'contact', 'お問い合わせ'); ?>より承っております。
			</p>
		</div>
	</div>
</div>