<h2>
	<?php echo $profile['c_name'].'へ'.$objective.'の応募が完了しました。'; ?>
</h2>
<div class="boxpaddingsmall">
	<p>
		<?php echo $profile['c_name'].'へ'.$objective.'の応募が完了しました。'; ?>
	</p>
	<p>
		動物病院からは、ご登録されたメールアドレスもしくは電話番号宛に折り返し連絡があります。
	</p>
</div>