<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-26 13:52:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 13:52:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 13:52:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 13:52:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 13:52:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 13:52:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 14:31:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 14:31:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 14:31:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:05:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 16:05:15 --> Notice - Undefined variable: email in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\mail.php on line 65
INFO - 2015-06-26 16:06:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:06:07 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 16:06:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:06:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:06:10 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 16:06:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:06:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:06:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:06:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 16:06:17 --> Notice - Undefined property: Fuel\Core\Database_MySQLi_Result::$count in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\mail.php on line 69
INFO - 2015-06-26 16:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:06:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 16:06:44 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/emailalreadyregisteredexception.php" does not contain class "EmailAlreadyRegisteredException" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-06-26 16:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:07:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:07:14 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 16:07:14 --> メールアドレス重複エラー: Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 16:11:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:11:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:11:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:19:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:19:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:19:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:19:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 16:19:22 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 16:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:25:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:25:57 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 16:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 16:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 16:26:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 16:26:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 16:26:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 18:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:41:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:41:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 18:41:33 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 18:41:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:41:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:41:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 18:41:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(`preuser_id`, `email`) VALUES ('f83c0e2a8a39b6f0adf28901edf592c49478ed47', 'a@a' at line 1 [ INSERT INTO  (`preuser_id`, `email`) VALUES ('f83c0e2a8a39b6f0adf28901edf592c49478ed47', 'a@a.com') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-06-26 18:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 18:45:19 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 18:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:45:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 18:45:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:45:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 18:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:45:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 18:45:36 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 18:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 18:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 18:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:56:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 18:56:04 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 18:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 18:56:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 18:56:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 18:56:12 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:09:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:09:38 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 19:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:09:40 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 19:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:09:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:09:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:09:55 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:21:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:21:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:21:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:21:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:21:22 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:22:32 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 19:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:22:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:22:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:22:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:22:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:22:43 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:28:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:28:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:28:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:28:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:28:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:28:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:30:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:30:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:30:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:31:03 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:46:19 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-26 19:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:46:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:46:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:46:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:46:27 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-26 19:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-26 19:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:48:47 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:48:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:48:47 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-26 19:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-26 19:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-26 19:48:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-26 19:48:55 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
