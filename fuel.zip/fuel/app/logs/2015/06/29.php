<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-29 20:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-29 20:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-29 20:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-29 20:56:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-29 20:56:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-29 20:56:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-29 20:56:03 --> Runtime Recoverable error - Object of class Fuel\Core\Database_MySQLi_Result could not be converted to string in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form\instance.php on line 201
INFO - 2015-06-29 21:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-29 21:37:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-29 21:37:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-29 21:37:07 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form\instance.php on line 201
