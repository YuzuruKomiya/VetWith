<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-16 12:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "admin"
INFO - 2015-06-16 12:58:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 12:58:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 12:58:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-16 12:58:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 12:58:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:40:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:40:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:40:17 --> Compile Error - Cannot redeclare class Auth\Auth_Group_Simplegroup in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\group\hospitalgroup.php on line 89
INFO - 2015-06-16 14:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:41:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:41:23 --> Error - Could not find asset: bootstrap-responsive.min.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-06-16 14:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:48:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:48:03 --> Error - Could not find asset: mystyle.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-06-16 14:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:48:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:48:04 --> Error - Could not find asset: mystyle.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-06-16 14:48:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:48:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:48:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:48:07 --> Error - Could not find asset: mystyle.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-06-16 14:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:49:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:49:03 --> Notice - Undefined index: FUEL_ENV in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\login.php on line 18
INFO - 2015-06-16 14:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:50:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:50:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:50:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:50:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:50:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:51:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:51:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:51:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:51:02 --> Fatal Error - Call to a member function login() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\studentauth.php on line 16
INFO - 2015-06-16 14:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:52:10 --> Fatal Error - Call to a member function login() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\studentauth.php on line 16
INFO - 2015-06-16 14:52:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:52:18 --> Fatal Error - Call to a member function login() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\studentauth.php on line 16
INFO - 2015-06-16 14:52:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:52:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:53:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 14:53:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:53:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:55:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 14:55:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:55:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 14:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 14:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 14:55:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 14:55:37 --> Fatal Error - Call to a member function create_user() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\studentauth.php on line 42
INFO - 2015-06-16 15:11:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:11:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:11:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 15:11:00 --> Notice - Use of undefined constant studentauth - assumed 'studentauth' in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\login.php on line 8
INFO - 2015-06-16 15:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:13:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:13:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:13:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 15:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 15:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:15:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 15:15:41 --> 1054 - Unknown column 'created_at' in 'field list' [ INSERT INTO `students` (`username`, `password`, `email`, `group`, `profile_fields`, `last_login`, `login_hash`, `created_at`) VALUES ('admin', 'NtgTF8q6Z9UyyUwQS7Ma5Bvj+uTrK/F66iMji9su1XY=', 'breeder.weaver@gmail.com', 1, 'a:0:{}', 0, '', 1434435340) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-06-16 15:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 15:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:26:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-16 15:26:54 --> 1054 - Unknown column 'created_at' in 'field list' [ INSERT INTO `students` (`username`, `password`, `email`, `group`, `profile_fields`, `last_login`, `login_hash`, `created_at`) VALUES ('admin', 'NtgTF8q6Z9UyyUwQS7Ma5Bvj+uTrK/F66iMji9su1XY=', 'breeder.weaver@gmail.com', 1, 'a:0:{}', 0, '', 1434436014) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-06-16 15:35:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/register"
INFO - 2015-06-16 15:35:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:35:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student"
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:36:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 15:36:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 15:36:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 15:36:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-16 21:43:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "studentauth/login"
INFO - 2015-06-16 21:43:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-16 21:43:09 --> Fuel\Core\Request::execute - Setting main Request
