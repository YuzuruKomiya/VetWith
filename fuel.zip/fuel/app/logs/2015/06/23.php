<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/invite"
INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:02:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/sturentregister/invite"
INFO - 2015-06-23 23:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-23 23:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/invite"
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:02:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-23 23:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-23 23:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-23 23:05:41 --> Fuel\Core\Request::execute - Setting main Request
