<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2015-06-15 10:12:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2015-06-15 18:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "check"
ERROR - 2015-06-15 18:19:20 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/check.php" does not contain class "Controller_Check" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-06-15 18:20:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "check"
INFO - 2015-06-15 18:20:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-15 18:20:18 --> Fuel\Core\Request::execute - Setting main Request
