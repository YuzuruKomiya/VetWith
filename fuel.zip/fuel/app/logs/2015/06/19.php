<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-19 13:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-19 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-19 13:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:41:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/login"
INFO - 2015-06-19 13:41:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:41:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/logout"
INFO - 2015-06-19 13:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-19 13:42:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-19 13:42:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-19 13:42:55 --> Fuel\Core\Request::execute - Setting main Request
