<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-28 14:19:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-28 14:19:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-28 14:19:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-28 14:33:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-28 14:33:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-28 14:33:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-28 14:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-28 14:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-28 14:35:39 --> Fuel\Core\Request::execute - Setting main Request
