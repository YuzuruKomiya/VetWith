<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-30 00:08:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:08:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:08:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:08:51 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form\instance.php on line 201
INFO - 2015-06-30 00:14:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:14:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:14:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:14:08 --> Notice - Undefined index: s_email in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\register.php on line 29
INFO - 2015-06-30 00:14:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-30 00:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:21:54 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:21:54 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
ERROR - 2015-06-30 00:21:54 --> Notice - Undefined variable: form in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 278
INFO - 2015-06-30 00:22:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-30 00:22:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:22:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:22:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:22:40 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
ERROR - 2015-06-30 00:22:40 --> Notice - Undefined variable: form in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 278
INFO - 2015-06-30 00:27:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
ERROR - 2015-06-30 00:27:14 --> Parsing Error - syntax error, unexpected ')' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 270
INFO - 2015-06-30 00:27:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:27:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:27:23 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:27:23 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
ERROR - 2015-06-30 00:27:23 --> Notice - Undefined variable: form in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 281
INFO - 2015-06-30 00:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:27:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:27:35 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
ERROR - 2015-06-30 00:27:35 --> Notice - Undefined variable: s_register_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register.php on line 6
INFO - 2015-06-30 00:35:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:35:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:35:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:35:39 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
ERROR - 2015-06-30 00:35:39 --> Notice - Undefined variable: s_email_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\invite.php on line 6
INFO - 2015-06-30 00:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:36:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:36:42 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/unko"
INFO - 2015-06-30 00:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:36:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:36:59 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/unko"
INFO - 2015-06-30 00:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:41:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:41:51 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/NULL"
INFO - 2015-06-30 00:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:41:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:41:56 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/NULL"
INFO - 2015-06-30 00:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:41:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:41:59 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-06-30 00:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-30 00:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-30 00:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:45:43 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:45:43 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-06-30 00:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/NULL"
INFO - 2015-06-30 00:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-30 00:45:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-30 00:45:49 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
