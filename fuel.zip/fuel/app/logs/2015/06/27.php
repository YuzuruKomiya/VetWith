<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-27 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 16:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 16:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 16:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 16:42:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 16:42:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:42:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 16:42:09 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-27 16:46:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 16:46:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:46:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 16:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 16:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:46:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 16:46:11 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-27 16:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 16:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 16:56:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 16:56:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 16:56:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 16:56:33 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 544
INFO - 2015-06-27 17:01:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:01:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:01:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:01:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:01:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:01:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-06-27 17:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:18:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:18:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:18:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:18:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 17:18:40 --> Compile Error - Can't use method return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\mail.php on line 73
INFO - 2015-06-27 17:19:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:19:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:19:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:19:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:19:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:19:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:36:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:36:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:36:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:36:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 17:36:36 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\uri.php on line 195
INFO - 2015-06-27 17:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:41:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 17:41:48 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\uri.php on line 195
INFO - 2015-06-27 17:45:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:45:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:45:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 17:45:21 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\uri.php on line 195
INFO - 2015-06-27 17:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:52:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-27 17:52:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:52:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 17:52:08 --> 1062 - Duplicate entry 'breeder.weaver@gmail.com' for key 'username' [ INSERT INTO `students` (`email`, `preuser_id`) VALUES ('breeder.weaver@gmail.com', 'a2566c5de25fce9e02da761f4eb7e1fa5f5274b2') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-06-27 17:57:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 17:57:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:57:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register"
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 17:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 21:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:18:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:18:50 --> Warning - include(C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php): failed to open stream: No such file or directory in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 243
INFO - 2015-06-27 21:19:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:19:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:19:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:20:00 --> Compile Error - Cannot redeclare class Fieldsetplus\Fieldsetplus_Field in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 155
INFO - 2015-06-27 21:21:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:21:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:21:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:21:06 --> Compile Error - Cannot redeclare class Fieldsetplus\Fieldsetplus_Field in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 155
INFO - 2015-06-27 21:21:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:21:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:21:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:21:07 --> Compile Error - Cannot redeclare class Fieldsetplus\Fieldsetplus_Field in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 155
INFO - 2015-06-27 21:21:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:21:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:21:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:21:34 --> Compile Error - Cannot redeclare class Fieldsetplus\Fieldsetplus_Field in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 155
INFO - 2015-06-27 21:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:28:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-27 21:28:33 --> Compile Error - Cannot redeclare class Fieldsetplus\Fieldsetplus_Field in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 155
INFO - 2015-06-27 21:33:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-27 21:33:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:33:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 21:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 21:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 21:39:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:39:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:39:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 21:39:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 21:39:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 21:39:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:32:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:32:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:32:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:32:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:32:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:32:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-27 22:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-06-27 22:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-27 22:38:28 --> Fuel\Core\Request::execute - Setting main Request
