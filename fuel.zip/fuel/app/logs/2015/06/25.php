<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-06-25 15:20:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:20:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:20:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:20:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:20:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:20:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:20:37 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:22:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:22:01 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:22:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:22:45 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:22:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:22:47 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:25:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:25:50 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:25:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:25:52 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:26:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:26:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:26:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:26:23 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:29:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:29:03 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:29:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:29:05 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:29:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:29:21 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:29:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:29:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:29:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:29:25 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:29:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:29:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:29:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:30:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:30:16 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:33:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:33:20 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:33:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:33:22 --> Fatal Error - Call to a member function build() on null in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 16
INFO - 2015-06-25 15:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:37:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:37:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send"
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:38:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:39:16 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 15:39:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:40:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:40:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:40:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:44:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:44:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:44:04 --> Fatal Error - Call to undefined method Fuel\Core\Fieldset_Field::add_csrf() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 32
INFO - 2015-06-25 15:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:44:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:44:36 --> Fatal Error - Call to undefined method Fuel\Core\Fieldset_Field::form() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 32
INFO - 2015-06-25 15:49:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 15:49:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 15:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 15:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:49:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 15:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 15:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:57:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 15:57:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:57:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 15:57:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 15:57:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 15:57:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 15:57:05 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:01:50 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 16:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 16:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:01:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:02:00 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:02:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:02:14 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:02:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:02:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:02:25 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:02:28 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:06:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:06:23 --> メール送信エラー: Failed sending emailController_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-06-25 16:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 16:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:10:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:10:16 --> メール送信エラー: Failed sending emailController_Student_Auth_StudentRegister::action_send_invitation
ERROR - 2015-06-25 16:10:16 --> Notice - Undefined variable: s_email_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\invite.php on line 6
INFO - 2015-06-25 16:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:17:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:17:25 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:30:20 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 16:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:30:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:30:26 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:30:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:30:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:30:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:30:47 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:31:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:31:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:31:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:31:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:31:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:31:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:31:25 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:31:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:31:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:31:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:32:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:32:05 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:33:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:33:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:33:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:33:33 --> Fatal Error - Cannot pass parameter 2 by reference in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 122
INFO - 2015-06-25 16:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:33:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:33:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:33:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:33:58 --> Warning - stream_socket_client():  in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 126
INFO - 2015-06-25 16:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:36:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:36:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:36:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:39:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:39:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:39:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:42:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:42:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:42:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:42:23 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:42:24 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:42:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:42:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:42:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:42:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:43:22 --> Fatal Error - Maximum execution time of 30 seconds exceeded in C:\Users\yuduru\work\fuelphp\fuel\core\bootstrap.php on line 96
INFO - 2015-06-25 16:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:43:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:43:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:43:53 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:44:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:44:15 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:44:39 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 16:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:44:41 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 16:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:44:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:44:49 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:45:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:45:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:45:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:45:55 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:47:18 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:47:44 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:47:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:47:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:47:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:47:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:47:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:48:00 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:48:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:48:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:48:55 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:49:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:49:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:49:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:49:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:49:50 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:49:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:49:57 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 16:53:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 16:53:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:53:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 16:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 16:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 16:53:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 16:53:15 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 17:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 17:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 17:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 17:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 17:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 17:02:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 17:02:59 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 21:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 21:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 21:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 21:58:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 21:58:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 21:58:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 21:58:55 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:00:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:00:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:00:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:00:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:00:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:00:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:00:13 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:00:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:00:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:00:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:00:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:00:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:00:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:01:34 --> Fatal Error - Maximum execution time of 30 seconds exceeded in C:\Users\yuduru\work\fuelphp\fuel\core\bootstrap.php on line 96
INFO - 2015-06-25 22:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:05:14 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 22:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:05:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:05:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:05:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:05:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:05:20 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:06:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:06:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:06:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:07:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:07:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:07:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:07:24 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:13:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:13:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:13:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:13:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:13:51 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:26:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:27:01 --> Error - Failed authentication. in C:\Users\yuduru\work\fuelphp\fuel\packages\email\classes\email\driver\smtp.php on line 218
INFO - 2015-06-25 22:27:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:27:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:27:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:28:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:28:07 --> Notice - Undefined variable: data in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 68
INFO - 2015-06-25 22:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:45:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:45:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:45:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-06-25 22:45:51 --> Notice - Undefined variable: post in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\sendinvite.php on line 2
INFO - 2015-06-25 22:54:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 22:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 22:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 22:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 22:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:36:37 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-06-25 23:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:36:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 23:36:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:36:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:46:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 23:46:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:46:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-06-25 23:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 23:48:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:48:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:48:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:48:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:48:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 23:48:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:48:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send"
INFO - 2015-06-25 23:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send_invitation"
INFO - 2015-06-25 23:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send_invitation"
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send_invitation"
INFO - 2015-06-25 23:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite/send_invitation"
INFO - 2015-06-25 23:50:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-06-25 23:50:35 --> Fuel\Core\Request::execute - Setting main Request
