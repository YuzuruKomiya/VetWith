<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-23 18:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-23 18:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-23 18:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-23 18:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-23 18:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-23 18:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-23 18:06:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-23 18:06:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-23 18:06:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-23 18:06:47 --> Fuel\Core\Request::execute - Setting main Request
