<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-04 17:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 17:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 17:16:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 17:16:18 --> Parsing Error - syntax error, unexpected ')' in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\studentauth.php on line 296
INFO - 2015-07-04 18:20:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 18:20:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:20:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:22:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:22:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:22:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 18:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:23:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 18:23:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:23:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 18:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:24:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 18:24:30 --> Notice - Undefined index: s_email in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register_confirm.php on line 75
INFO - 2015-07-04 18:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:33:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 18:33:32 --> Notice - Undefined index: s_email in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register_confirm.php on line 75
INFO - 2015-07-04 18:33:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 18:33:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:33:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:35:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:35:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:35:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 18:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:35:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 18:35:35 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `l_name` = '小宮', `l_name_kana` = 'コミヤ', `f_name` = '弦', `f_name_kana` = 'ユヅル', `birthday` = '1990-8-22', `gender` = '男性', `university` = '東京大学', `grade` = '学部6年', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:0:{}', `last_login` = 0, `login_hash` = '', `created_at` = 1436002535 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 18:41:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 18:41:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:41:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:41:25 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-04 18:41:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 18:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 18:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 18:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 18:41:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 18:41:29 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `l_name` = '小宮', `l_name_kana` = 'コミヤ', `f_name` = '弦', `f_name_kana` = 'ユヅル', `birthday` = '1990-8-22', `gender` = '男性', `university` = '東京大学', `grade` = '学部6年', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:0:{}', `last_login` = 0, `login_hash` = '', `created_at` = 1436002889 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 20:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 20:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 20:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 20:46:01 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-04 20:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 20:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 20:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 20:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 20:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 20:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 20:49:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 20:49:49 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `l_name` = '小宮', `l_name_kana` = 'コミヤ', `f_name` = '弦', `f_name_kana` = 'ユヅル', `birthday` = '1990-8-22', `gender` = '男性', `university` = '東京大学', `grade` = '学部6年', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:0:{}', `last_login` = 0, `login_hash` = '', `created_at` = 1436010589 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 21:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 21:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 21:29:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 21:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 21:29:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 21:29:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:29:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 21:29:50 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:8:{s:6:\"l_name\";s:6:\"小宮\";s:6:\"f_name\";s:3:\"弦\";s:11:\"l_name_kana\";s:9:\"コミヤ\";s:11:\"f_name_kana\";s:9:\"ユヅル\";s:8:\"birthday\";s:9:\"1990-8-22\";s:6:\"gender\";s:6:\"男性\";s:10:\"university\";s:12:\"東京大学\";s:5:\"grade\";s:10:\"学部6年\";}', `last_login` = 0, `login_hash` = '', `created_at` = 1436012989 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 21:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 21:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 21:33:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 21:33:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:33:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 21:33:31 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:8:{s:6:\"l_name\";s:6:\"小宮\";s:6:\"f_name\";s:3:\"弦\";s:11:\"l_name_kana\";s:9:\"コミヤ\";s:11:\"f_name_kana\";s:9:\"ユヅル\";s:8:\"birthday\";s:9:\"1990-8-22\";s:6:\"gender\";s:6:\"男性\";s:10:\"university\";s:12:\"東京大学\";s:5:\"grade\";s:10:\"学部6年\";}', `last_login` = 0, `login_hash` = '', `created_at` = 1436013211 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 21:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 21:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 21:38:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 21:38:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:38:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 21:38:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 21:38:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 21:38:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 21:38:41 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:8:{s:6:\"l_name\";s:6:\"小宮\";s:6:\"f_name\";s:3:\"弦\";s:11:\"l_name_kana\";s:9:\"コミヤ\";s:11:\"f_name_kana\";s:9:\"ユヅル\";s:8:\"birthday\";s:9:\"1990-8-22\";s:6:\"gender\";s:6:\"男性\";s:10:\"university\";s:12:\"東京大学\";s:5:\"grade\";s:10:\"学部6年\";}', `last_login` = 0, `login_hash` = '', `created_at` = 1436013521 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 22:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 22:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 22:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-04 22:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 22:04:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 22:04:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 22:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 22:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 22:04:10 --> 1062 - Duplicate entry 'yuzuyuzucom-a@a.a' for key 'username' [ UPDATE `students` SET `preuser_id` = 'deleted', `username` = 'yuzuyuzucom', `password` = 't1vZwYXHGIdGGKMrOb8kL1U0xUcqqs/xGv1ny217qSE=', `email` = 'a@a.a', `group` = 1, `profile_fields` = 'a:8:{s:6:\"l_name\";s:6:\"小宮\";s:6:\"f_name\";s:3:\"弦\";s:11:\"l_name_kana\";s:9:\"コミヤ\";s:11:\"f_name_kana\";s:9:\"ユヅル\";s:8:\"birthday\";s:9:\"1990-8-22\";s:6:\"gender\";s:6:\"男性\";s:10:\"university\";s:12:\"東京大学\";s:5:\"grade\";s:10:\"学部6年\";}', `last_login` = 0, `login_hash` = '', `created_at` = 1436015050 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-04 22:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 22:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 22:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 22:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 22:04:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 22:04:47 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-07-04 23:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 23:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 23:30:48 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-04 23:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 23:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:31:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 23:31:04 --> Error - 無効なURLです。 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\register.php on line 184
INFO - 2015-07-04 23:31:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-04 23:31:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:31:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 23:31:33 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-04 23:31:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-04 23:31:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:31:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 23:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-04 23:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:31:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-04 23:31:49 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-07-04 23:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-04 23:33:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:33:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 23:34:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/382a54c896e420cc59b85c635bc94ede1d173e83"
INFO - 2015-07-04 23:34:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:34:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 23:34:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-04 23:34:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:34:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-04 23:34:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-04 23:34:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-04 23:34:44 --> Fuel\Core\Request::execute - Setting main Request
