<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-13 16:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:22:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-13 16:22:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:22:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 16:22:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:22:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:24:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 16:24:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:24:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:24:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-13 16:24:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:24:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:51:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:51:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:51:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 16:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 16:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 16:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 18:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:03:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:03:33 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 24
INFO - 2015-07-13 18:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:04:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:04:05 --> Notice - Undefined index: zip1 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 80
INFO - 2015-07-13 18:33:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:33:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:33:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:33:38 --> Fatal Error - Class 'Clinic_Auth' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:34:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:34:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:34:14 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:34:14 --> Fatal Error - Class 'Contoroller_Clinic_Auth' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:34:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:34:48 --> Fatal Error - Class 'Clinic_Auth' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:34:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:34:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:34:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:34:49 --> Fatal Error - Class 'Clinic_Auth' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:37:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:37:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:37:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:37:44 --> Fatal Error - Undefined class constant 'prefecture' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:37:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:37:47 --> Fatal Error - Undefined class constant 'prefecture' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 103
INFO - 2015-07-13 18:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 18:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 18:41:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 18:41:53 --> Notice - Undefined index: start_time in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 140
INFO - 2015-07-13 20:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 20:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 20:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 20:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 20:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 20:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 20:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 20:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 20:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 20:54:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-13 20:54:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 20:54:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 20:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 20:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 20:54:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 20:54:42 --> Notice - Undefined index: end_time in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 150
INFO - 2015-07-13 21:36:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:36:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:36:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 21:36:41 --> Notice - Undefined variable: c_detail_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\set_detail.php on line 7
INFO - 2015-07-13 21:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 21:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:49:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 21:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-13 21:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 21:52:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:52:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:52:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 21:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 21:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 21:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 21:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-13 23:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:10:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 23:10:01 --> 本登録エラー: 無効なURLです。Controller_Clinic_Auth::action_register
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_confirm"
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:10:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_confirm"
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_confirm"
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_confirm"
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:13:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:13:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-13 23:13:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:13:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 23:13:51 --> 本登録エラー: 無効なURLです。Controller_Clinic_Auth::action_register
INFO - 2015-07-13 23:13:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-13 23:13:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:13:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:21:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/eedcebabe69fb5b6ffa4b8a699db2688152459d9"
INFO - 2015-07-13 23:21:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:21:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 23:21:06 --> Runtime Notice - Accessing static property Controller_Clinic_Auth::$prefecture as non static in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth.php on line 177
INFO - 2015-07-13 23:21:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/eedcebabe69fb5b6ffa4b8a699db2688152459d9"
INFO - 2015-07-13 23:21:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:21:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 23:21:12 --> Runtime Notice - Accessing static property Controller_Clinic_Auth::$prefecture as non static in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth.php on line 177
INFO - 2015-07-13 23:23:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/eedcebabe69fb5b6ffa4b8a699db2688152459d9"
INFO - 2015-07-13 23:23:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:23:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-13 23:23:06 --> Fatal Error - Undefined class constant 'prefecture' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth.php on line 179
INFO - 2015-07-13 23:23:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/eedcebabe69fb5b6ffa4b8a699db2688152459d9"
INFO - 2015-07-13 23:23:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:23:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/eedcebabe69fb5b6ffa4b8a699db2688152459d9"
INFO - 2015-07-13 23:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-13 23:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:25:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_completion"
INFO - 2015-07-13 23:25:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:25:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:33:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-13 23:33:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:33:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 23:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:33:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 23:33:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:33:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 23:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:34:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 23:34:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:34:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-13 23:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-13 23:46:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-13 23:46:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-13 23:46:44 --> Fuel\Core\Request::execute - Setting main Request
