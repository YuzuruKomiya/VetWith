<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-14 00:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-14 00:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-14 00:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-14 00:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:09:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:09:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:09:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-14 00:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-14 00:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:11:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-14 00:11:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:11:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:12:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-14 00:12:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:12:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:12:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:12:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:12:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:12:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:12:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:12:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:12:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:12:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:12:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:14:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:14:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:14:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:20:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:20:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:20:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 00:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 00:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 00:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 23:59:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-14 23:59:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 23:59:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 23:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-14 23:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 23:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 23:59:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-14 23:59:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 23:59:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-14 23:59:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-14 23:59:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-14 23:59:51 --> Fuel\Core\Request::execute - Setting main Request
