<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-05 16:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 16:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:52:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 16:52:21 --> Compile Error - Cannot redeclare class Auth\Auth_Login_Studentauth in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 632
ERROR - 2015-07-05 16:52:21 --> Compile Error - Cannot redeclare class Auth\Auth_Login_Studentauth in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 632
INFO - 2015-07-05 16:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 16:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:52:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 16:52:45 --> Compile Error - Cannot redeclare class Auth\Auth_Login_Studentauth in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 632
INFO - 2015-07-05 16:52:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-05 16:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:52:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 16:52:48 --> Compile Error - Cannot redeclare class Auth\Auth_Login_Studentauth in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 632
INFO - 2015-07-05 16:55:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 16:55:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:55:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-05 16:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/973d5d7ae4e9da16e0f79ab163045aae2b23d6bf"
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/973d5d7ae4e9da16e0f79ab163045aae2b23d6bf"
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 16:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/sturentregister/register/973d5d7ae4e9da16e0f79ab163045aae2b23d6bf"
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:00:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/973d5d7ae4e9da16e0f79ab163045aae2b23d6bf"
INFO - 2015-07-05 17:00:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:00:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 17:02:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:02:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/973d5d7ae4e9da16e0f79ab163045aae2b23d6bf"
INFO - 2015-07-05 17:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 17:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-05 17:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 17:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-05 17:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:04:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 17:04:18 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-07-05 17:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-05 17:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/a8a1e38888d3484d0ddccbdf23b47135e6ebdf49"
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/a8a1e38888d3484d0ddccbdf23b47135e6ebdf49"
INFO - 2015-07-05 17:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 17:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:06:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-05 17:06:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:06:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 17:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-05 17:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 17:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:08:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-05 21:08:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:08:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:08:03 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth_StudentRegister::action_send_invitation
INFO - 2015-07-05 21:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/send_invitation"
INFO - 2015-07-05 21:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/8294fe986adac30856f359766e821671ab86d421"
INFO - 2015-07-05 21:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:12:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 21:12:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:12:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:12:02 --> 1054 - Unknown column 'LOWER("username")' in 'field list' [ SELECT `LOWER("username")` FROM `students` WHERE `username` = 'aaaaaaaa' ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-05 21:13:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/8294fe986adac30856f359766e821671ab86d421"
INFO - 2015-07-05 21:13:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:13:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:13:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 21:13:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:13:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:13:36 --> 1054 - Unknown column 'LOWER ("username")' in 'field list' [ SELECT `LOWER ("username")` FROM `students` WHERE `username` = 'aaaaaaaa' ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-05 21:14:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 21:14:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:14:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:15:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 21:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:19:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-05 21:19:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:19:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:19:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_completion"
INFO - 2015-07-05 21:19:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:19:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
ERROR - 2015-07-05 21:20:02 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/template/clinicauthtemplate.php" does not contain class "Controller_Template_ClinicAuthTemplate" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-07-05 21:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
ERROR - 2015-07-05 21:21:51 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/template/clinicauthtemplate.php" does not contain class "Controller_Template_ClinicAuthTemplate" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-07-05 21:22:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
ERROR - 2015-07-05 21:22:11 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/template/clinicauthtemplate.php" does not contain class "Controller_Template_ClinicAuthTemplate" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-07-05 21:22:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
INFO - 2015-07-05 21:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:22:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:22:48 --> Notice - Undefined variable: c_email_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\auth\invite.php on line 6
INFO - 2015-07-05 21:23:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
INFO - 2015-07-05 21:23:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:23:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/send_invitation"
INFO - 2015-07-05 21:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/0d86a24d8722879e1933b87e34117c8f89c65551"
INFO - 2015-07-05 21:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:30:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:30:39 --> Fatal Error - Class 'Model_Ctudent_Auth_Register' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 32
INFO - 2015-07-05 21:31:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/0d86a24d8722879e1933b87e34117c8f89c65551"
INFO - 2015-07-05 21:31:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:31:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:31:17 --> Notice - Undefined variable: s_email in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 100
INFO - 2015-07-05 21:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/0d86a24d8722879e1933b87e34117c8f89c65551"
INFO - 2015-07-05 21:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:31:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-05 21:31:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:31:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-05 21:31:50 --> Notice - Undefined index: c_password in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\auth\register_confirm.php on line 45
INFO - 2015-07-05 21:32:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/0d86a24d8722879e1933b87e34117c8f89c65551"
INFO - 2015-07-05 21:32:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:32:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-05 21:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:32:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-05 21:32:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-05 21:32:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-05 21:32:43 --> Fuel\Core\Request::execute - Setting main Request
