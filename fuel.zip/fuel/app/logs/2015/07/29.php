<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-29 00:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-29 00:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 00:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 11:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-29 11:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 11:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 11:08:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 11:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 11:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 11:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 12:53:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 12:53:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 12:53:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-29 14:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:36:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 14:36:13 --> Fatal Error - Using $this when not in object context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\str.php on line 14
INFO - 2015-07-29 14:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-29 14:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:36:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:37:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-29 14:37:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:37:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:50:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 14:50:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:50:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 14:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 14:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 14:59:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 14:59:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 14:59:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 15:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-29 15:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:19:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 15:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:20:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-29 15:20:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:20:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:20:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 15:20:50 --> Warning - Creating default object from empty value in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 21
INFO - 2015-07-29 15:21:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:21:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:21:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 15:21:03 --> Notice - Undefined variable: header in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 37
INFO - 2015-07-29 15:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
ERROR - 2015-07-29 15:25:33 --> Fatal Error - Class 'Controller_EveryUserTemplate' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 4
INFO - 2015-07-29 15:26:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
ERROR - 2015-07-29 15:26:47 --> Fatal Error - Class 'Controller_EveryUserTemplate' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 4
INFO - 2015-07-29 15:26:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
ERROR - 2015-07-29 15:26:49 --> Fatal Error - Class 'Controller_EveryUserTemplate' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 4
INFO - 2015-07-29 15:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
ERROR - 2015-07-29 15:26:50 --> Fatal Error - Class 'Controller_EveryUserTemplate' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 4
INFO - 2015-07-29 15:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
ERROR - 2015-07-29 15:26:50 --> Fatal Error - Class 'Controller_EveryUserTemplate' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 4
INFO - 2015-07-29 15:27:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:37:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:37:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-29 15:37:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:37:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:37:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-29 15:37:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:37:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-29 15:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-29 15:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:38:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-29 15:38:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:38:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 15:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 15:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 15:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:06:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 17:06:53 --> Notice - Undefined variable: c_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers.php on line 4
INFO - 2015-07-29 17:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:09:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:09:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 17:09:40 --> Notice - Undefined variable: catchcopy in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers.php on line 5
INFO - 2015-07-29 17:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:09:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 17:09:55 --> Notice - Undefined variable: operation in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers.php on line 5
INFO - 2015-07-29 17:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:21:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:21:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:21:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:23:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:23:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:23:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 17:23:15 --> Notice - Undefined variable: carrer in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers.php on line 134
INFO - 2015-07-29 17:23:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:23:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:23:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:31:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:31:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-29 17:32:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-29 17:32:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-29 17:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-29 17:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-29 17:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-29 17:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-29 17:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:32:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:32:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:32:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:33:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:33:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:33:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:43:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:43:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-29 17:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 17:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 17:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 17:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-29 18:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:01:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:01:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:01:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 18:01:58 --> Notice - Undefined variable: catchcopy in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\offer.php on line 5
INFO - 2015-07-29 18:02:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-29 18:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:09:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:09:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:09:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:09:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-29 18:09:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:09:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:09:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:09:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:09:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:15:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:15:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:15:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:16:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:16:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:16:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:16:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:16:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:16:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:17:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:17:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:17:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:18:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:20:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:20:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:20:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:20:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:20:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:20:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:32:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:32:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:32:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:38:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:38:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:38:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:38:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register"
INFO - 2015-07-29 18:38:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:38:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 18:38:57 --> 本登録エラー: 無効なURLです。Controller_Student_Auth::action_register
INFO - 2015-07-29 18:39:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register"
INFO - 2015-07-29 18:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:39:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 18:39:53 --> 本登録エラー: 無効なURLです。Controller_Student_Auth::action_register
INFO - 2015-07-29 18:39:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:39:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:39:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-29 18:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:41:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:41:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:41:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:41:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:41:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:41:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:43:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-29 18:43:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:43:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:48:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 18:48:10 --> Runtime Recoverable error - Argument 2 passed to Fuel\Core\Form::open() must be of the type array, string given, called in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\not_login.php on line 9 and defined in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form.php on line 78
INFO - 2015-07-29 18:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:48:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:48:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-29 18:48:45 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form\instance.php on line 201
INFO - 2015-07-29 18:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:52:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:52:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:53:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-29 18:53:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:53:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 18:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 18:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 18:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 22:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 22:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 22:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 22:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 22:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 22:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 22:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 22:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 22:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 22:16:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-29 22:16:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 22:16:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-29 22:38:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-29 22:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-29 22:38:53 --> Fuel\Core\Request::execute - Setting main Request
