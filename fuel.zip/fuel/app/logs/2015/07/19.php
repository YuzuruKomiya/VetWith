<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-19 00:24:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 00:24:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 00:24:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 00:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-19 00:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 00:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 00:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-19 00:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 00:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 00:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 00:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 00:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 00:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-19 00:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 00:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:43:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 11:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:43:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-19 11:43:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:43:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:54:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-19 11:54:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:54:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-19 11:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:55:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-19 11:55:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:55:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 11:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-19 11:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 11:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-19 11:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:57:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:57:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 11:57:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:57:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-19 11:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 11:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 11:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 11:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:54:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:54:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:54:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 12:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 12:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 12:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:01:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:01:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:01:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:03:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 13:03:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:03:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-19 13:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:19:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:19:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:19:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:21:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:21:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:21:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:21:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:21:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:21:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:22:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:22:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:22:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 13:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 13:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 13:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:00:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:00:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:00:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:09:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/img/clinic"
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/assets/img/clinic"
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:09:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:12:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:26:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:27:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:27:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:27:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:28:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:28:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:28:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:28:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:28:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:28:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:34:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:34:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:34:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:34:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:35:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:35:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:35:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:35:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:35:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:35:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:35:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:35:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:35:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:35:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:35:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 14:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 14:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 14:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:00:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:00:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:00:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:07:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:07:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:07:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:20:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:20:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:20:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:20:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:20:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:20:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:23:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:23:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:23:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:32:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:32:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:32:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:32:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:34:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:34:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:34:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:36:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:36:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:36:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:36:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:36:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:36:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:37:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:37:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:37:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:37:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:37:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:37:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:43:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:47:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:47:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:47:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:57:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:57:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:57:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:57:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:57:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:57:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 15:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 15:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 15:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 16:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 16:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 16:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 16:17:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 16:17:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 16:17:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 16:27:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 16:27:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 16:27:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 16:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 16:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 16:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 17:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 17:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 17:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 18:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 18:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 18:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 18:07:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 18:07:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 18:07:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 18:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 18:31:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 18:31:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-19 18:32:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-19 18:32:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-19 18:32:52 --> Fuel\Core\Request::execute - Setting main Request
