<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-18 17:09:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:09:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:09:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 17:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:09:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:36:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:36:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:36:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:37:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-18 17:37:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:37:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 17:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 17:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:45:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:45:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:45:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 17:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 17:55:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 17:55:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:16:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 18:16:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:16:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:17:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 18:17:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:17:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 18:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 18:54:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:54:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:55:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 18:55:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:55:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:55:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 18:55:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:55:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 18:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 18:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 18:59:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 18:59:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 18:59:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:00:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 19:00:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:00:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:00:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:00:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:00:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:00:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 19:00:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:00:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:00:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:00:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:00:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:08:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 19:08:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:08:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:09:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 19:09:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:09:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 19:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:10:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:10:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:10:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 19:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 19:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 19:11:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:06:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-18 20:06:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 20:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:06:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:16:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:16:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:16:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:16:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:16:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:16:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:17:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:18:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:18:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:18:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 20:22:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 20:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 20:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 22:44:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 22:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 22:44:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 22:44:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 22:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:44:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 22:44:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:44:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 22:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 22:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 22:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:52:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-18 22:52:53 --> Error - The requested view could not be found: welcome.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-07-18 22:53:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 22:53:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:53:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-18 22:53:28 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-07-18 22:54:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 22:54:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:54:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-18 22:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-18 22:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 22:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 22:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 23:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-18 23:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-18 23:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:04:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:04:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:04:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:22:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:22:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:22:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:22:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:22:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:22:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:22:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:24:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-18 23:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-18 23:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-18 23:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-18 23:50:14 --> Fuel\Core\Request::execute - Setting main Request
