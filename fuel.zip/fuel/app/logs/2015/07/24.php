<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-24 12:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 12:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 12:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 12:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-24 12:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 12:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 12:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-24 12:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 12:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 13:35:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-24 13:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 13:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 13:35:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 13:35:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 13:35:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 13:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-24 13:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 13:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-24 14:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:31:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-24 14:31:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:31:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:31:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 14:31:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:31:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:32:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 14:32:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:32:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:32:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 14:32:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:32:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-24 14:34:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-24 14:34:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:34:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:34:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:34:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:36:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:37:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:37:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:37:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:37:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:37:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:37:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-24 14:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:39:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:39:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:39:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:46:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:46:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:46:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:46:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:46:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:46:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:56:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:56:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:56:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 14:59:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 14:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 14:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:03:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:03:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:03:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:04:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:04:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:04:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:17:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:17:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:17:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:22:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:22:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:22:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:27:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:27:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:27:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:33:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:33:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:33:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:33:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:33:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:33:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:33:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:33:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:33:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:34:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:34:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-24 15:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-24 15:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-24 15:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-24 15:38:46 --> Fuel\Core\Request::execute - Setting main Request
