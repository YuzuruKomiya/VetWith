<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-12 00:06:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 00:06:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:06:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-12 00:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:08:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:08:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 00:08:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:08:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:09:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-12 00:09:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:09:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:12:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-12 00:12:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:12:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-12 00:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-12 00:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:14:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-12 00:14:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:14:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:14:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-12 00:14:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:14:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-12 00:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:15:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:15:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:15:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 00:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 13:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:50:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-12 13:50:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:50:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 13:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:55:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 13:55:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:55:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 13:59:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 13:59:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 13:59:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:13:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:13:10 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 21
INFO - 2015-07-12 15:14:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:14:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:14:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:16:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:16:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:16:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:16:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:16:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:16:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:17:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:24:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:24:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:24:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:24:50 --> Notice - Undefined index: prfile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 10
INFO - 2015-07-12 15:24:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:24:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:24:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:24:57 --> Error - View variable is not set: profile in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-07-12 15:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:25:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:25:29 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 21
INFO - 2015-07-12 15:26:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:26:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:26:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:26:03 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 21
INFO - 2015-07-12 15:28:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:28:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:28:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 15:28:40 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 21
INFO - 2015-07-12 15:28:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:28:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:28:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:36:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:36:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:36:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:36:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:44:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:44:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:44:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 15:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 15:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 15:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 16:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 16:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 16:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 16:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 16:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 16:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 16:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 16:07:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 16:07:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:46:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:46:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:46:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:46:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:46:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:46:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:46:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:47:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:47:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:47:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:47:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:47:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:47:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 17:55:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 17:55:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 17:55:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 18:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:09:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 18:09:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:09:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:09:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 18:09:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:09:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:38:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 18:38:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:38:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 18:38:22 --> Notice - Undefined variable: data in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 15
INFO - 2015-07-12 18:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 18:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-12 18:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:55:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 18:55:39 --> Notice - Undefined variable: data in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 69
INFO - 2015-07-12 18:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-12 18:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-12 18:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 18:58:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-12 18:58:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 18:58:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:13:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-12 20:13:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:13:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:13:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-12 20:13:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:13:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:52:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 20:52:31 --> Error - Theme "default" could not be found. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\theme.php on line 867
INFO - 2015-07-12 20:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:52:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 20:52:59 --> Error - Theme "default" could not be found. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\theme.php on line 867
INFO - 2015-07-12 20:53:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:53:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:53:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-12 20:53:14 --> Error - Theme "default" could not be found. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\theme.php on line 867
INFO - 2015-07-12 20:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:56:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:56:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:56:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 20:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 20:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 20:57:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 21:28:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 21:28:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 21:28:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 21:31:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 21:31:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 21:31:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 21:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 21:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 21:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 21:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 21:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 21:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-12 21:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "sample"
INFO - 2015-07-12 21:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-12 21:36:44 --> Fuel\Core\Request::execute - Setting main Request
