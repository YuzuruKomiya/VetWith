<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-03 18:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-03 18:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-03 18:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-03 19:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-03 19:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-03 19:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-03 19:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-03 19:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-03 19:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-03 19:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-03 19:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-03 19:41:56 --> Fuel\Core\Request::execute - Setting main Request
