<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-21 12:44:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-21 12:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-21 12:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 12:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 12:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 12:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 12:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 12:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 13:29:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 13:29:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 13:29:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 13:42:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 13:42:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 13:42:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 13:43:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 13:43:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 13:43:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 13:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 13:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 13:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 13:45:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 13:45:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 13:45:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-21 21:48:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-21 21:48:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-21 21:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 21:48:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 21:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:48:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:48:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:48:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:50:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:50:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:50:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:54:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:56:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:56:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:56:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:57:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 21:57:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:57:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:57:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 21:57:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:57:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 21:58:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 21:58:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 21:58:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:01:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:08:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:08:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:08:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:09:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:09:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:14:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:14:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:14:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:15:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:15:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:15:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:30:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:30:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:30:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 22:34:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 22:34:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 22:34:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 23:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 23:05:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:05:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 23:05:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:05:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 23:05:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 23:05:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 23:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-21 23:05:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:05:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 23:05:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-21 23:05:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-21 23:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-21 23:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-21 23:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-21 23:05:52 --> Fuel\Core\Request::execute - Setting main Request
