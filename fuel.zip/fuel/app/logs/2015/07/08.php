<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-08 15:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 15:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 15:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 15:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 15:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 15:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 17:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 17:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 17:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 17:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 17:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 17:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 17:55:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 17:55:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 17:55:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 17:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-08 17:55:34 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 372
INFO - 2015-07-08 18:30:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:30:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:30:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:30:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:30:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:30:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:30:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-08 18:30:27 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 372
INFO - 2015-07-08 18:39:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:39:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:40:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:40:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:40:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 18:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 18:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:57:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:57:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:57:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 18:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 18:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 18:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 18:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 18:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 19:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:04:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-08 19:04:53 --> Notice - Undefined variable: input in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 406
INFO - 2015-07-08 19:05:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 19:05:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:05:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:05:55 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-08 19:05:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:06:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 19:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 19:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:06:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 19:06:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-08 19:06:30 --> Notice - Undefined variable: input in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 406
INFO - 2015-07-08 19:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-08 19:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:29:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 19:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
INFO - 2015-07-08 19:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/send_invitation"
INFO - 2015-07-08 19:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/e6ce127fb6e5eaa26ab097b1f496ed3e47451cd9"
INFO - 2015-07-08 19:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:33:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/e6ce127fb6e5eaa26ab097b1f496ed3e47451cd9"
INFO - 2015-07-08 19:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:41:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:42:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/e6ce127fb6e5eaa26ab097b1f496ed3e47451cd9"
INFO - 2015-07-08 19:42:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:42:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:42:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/e6ce127fb6e5eaa26ab097b1f496ed3e47451cd9"
INFO - 2015-07-08 19:42:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:42:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:50:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-08 19:50:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:50:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 19:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-08 19:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 19:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:35:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-08 22:35:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:35:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:51:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-08 22:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/index"
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:51:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:51:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/login"
INFO - 2015-07-08 22:51:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:51:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:53:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:53:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:53:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic"
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:58:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:59:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:59:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-08 22:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic"
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-08 22:59:20 --> Fuel\Core\Request::execute - Setting main Request
