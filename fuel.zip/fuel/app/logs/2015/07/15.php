<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-15 00:00:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:00:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:00:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:02:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:02:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:03:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:03:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:03:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:03:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:03:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:03:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:12:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:12:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:12:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:12:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:12:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:13:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:13:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:15:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:15:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:15:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:16:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 00:16:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 00:16:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 00:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 00:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-15 00:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 00:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:32:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:32:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:33:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 10:33:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:33:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 10:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 10:53:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 10:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 10:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detai_completion"
INFO - 2015-07-15 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-15 16:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:51:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-15 16:51:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:51:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 16:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-15 16:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detai_completion"
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-15 16:52:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-15 16:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 16:52:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:52:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 16:52:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:52:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:53:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 16:53:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:53:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 16:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:53:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:53:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:53:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:19 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-15 16:55:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 16:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 16:55:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:55:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:49 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-15 16:55:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:52 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-15 16:55:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 16:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-15 16:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 16:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 16:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 16:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:44:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-15 17:45:00 --> Parsing Error - syntax error, unexpected ')', expecting ',' or ';' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 17
INFO - 2015-07-15 17:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:45:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-15 17:45:22 --> Parsing Error - syntax error, unexpected ')', expecting ',' or ';' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 17
INFO - 2015-07-15 17:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:45:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:45:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-15 17:45:26 --> Parsing Error - syntax error, unexpected ')', expecting ',' or ';' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 17
INFO - 2015-07-15 17:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:45:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:45:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:45:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:47:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:47:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:47:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-15 17:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:04 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-15 17:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:48:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:48:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:48:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:48:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 17:48:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:48:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:50:14 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-15 17:50:15 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 19
INFO - 2015-07-15 17:53:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:53:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:53:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:53:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:53:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:53:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:54:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:54:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:54:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:54:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:54:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:54:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 17:59:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 17:59:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 17:59:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 18:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 18:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 18:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 18:06:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 18:06:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 18:06:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 18:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-15 18:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 18:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-15 18:37:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-15 18:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-15 18:37:55 --> Fuel\Core\Request::execute - Setting main Request
