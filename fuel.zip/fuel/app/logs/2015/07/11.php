<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-11 14:19:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-11 14:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 14:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 14:19:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 14:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 14:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 14:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:09:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:09:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 15:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:09:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 15:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:39:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:39:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:39:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:43:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:43:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:43:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:44:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:48:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:48:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:48:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:48:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:48:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:48:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:50:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:50:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:50:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:52:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:52:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:52:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:58:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:58:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:58:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:58:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:58:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:58:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:59:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:59:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:59:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 15:59:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 15:59:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 15:59:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:00:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:03:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:03:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:03:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:03:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:03:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:04:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:04:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:04:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:47:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 16:47:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:47:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 16:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 16:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 16:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/bootstrap-responsive.min"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/mystyle"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/bootstrap.min"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:20:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 17:20:45 --> Error - Could not find asset: bootstrap.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
ERROR - 2015-07-11 17:20:45 --> Error - Could not find asset: bootstrap.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
ERROR - 2015-07-11 17:20:45 --> Error - Could not find asset: bootstrap.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-07-11 17:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:39:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:39:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:39:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:44:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:44:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:44:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:48:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:48:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:48:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:48:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:48:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:48:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:50:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:50:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:50:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:53:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:53:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:53:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:54:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:54:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:54:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:57:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:57:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:57:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:57:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:57:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:57:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:58:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 17:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 17:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-11 17:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:59:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 17:59:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:59:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 17:59:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 18:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:00:23 --> Error - Could not find asset: bootstrap-responsive.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-07-11 18:00:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 18:00:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-11 18:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:00:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:00:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:00:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:05:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:05:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:05:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:05:51 --> Error - Could not find asset: normalize.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-07-11 18:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:06:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:06:04 --> Error - Could not find asset: mystyle.css in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-07-11 18:06:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:06:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:06:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:07:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:07:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:07:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 18:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:09:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-07-11 18:09:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:09:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invitre"
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:09:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 18:09:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:09:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:09:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:09:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:09:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:09:52 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:12:03 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-11 18:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:12:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 18:12:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:12:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:12:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:12:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:12:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:12:10 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:12:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:12:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:12:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:12:36 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:13:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:13:40 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:14:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:14:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:14:10 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:15:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:15:50 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:16:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:16:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:16:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-11 18:16:48 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-07-11 18:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 18:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:19:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:19:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-07-11 18:19:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:19:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:21:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:21:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:21:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:21:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:21:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:21:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:32:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:38:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:38:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:38:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:39:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:45:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:45:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:45:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:47:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:47:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:47:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 18:48:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 18:48:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 18:48:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:08:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:08:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:08:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:27:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 19:27:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:27:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-07-11 19:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:30:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:30:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:30:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:31:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:31:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:31:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:36:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:36:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:36:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:37:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:37:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:37:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 19:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 19:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 19:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:02:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:02:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:02:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:04:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:04:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:04:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:04:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:04:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:04:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:08:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:08:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:08:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:08:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:08:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:08:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:11:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:11:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:17:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:17:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:22:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:22:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:22:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:24:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:24:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:24:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:27:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:27:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:27:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:27:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:28:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:28:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:28:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:31:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:31:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:31:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:31:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:31:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:31:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:36:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:36:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:36:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:36:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:36:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:36:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:45:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:45:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 20:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:56:59 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 20:56:59 --> Notice - Field with this name exists already in this fieldset: "name". in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 372
DEBUG - 2015-07-11 20:56:59 --> Notice - Unknown key after which to insert the new value into the array. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 376
ERROR - 2015-07-11 20:56:59 --> Error - Field "" does not exist in this Fieldset. Field "name" can not be added. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 378
INFO - 2015-07-11 20:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 20:59:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 20:59:43 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 20:59:43 --> Notice - Field with this name exists already in this fieldset: "name". in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 372
DEBUG - 2015-07-11 20:59:43 --> Notice - Unknown key after which to insert the new value into the array. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 376
ERROR - 2015-07-11 20:59:43 --> Error - Field "name" does not exist in this Fieldset. Field "name" can not be added. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 378
INFO - 2015-07-11 21:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:00:26 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 21:00:27 --> Notice - Field with this name exists already in this fieldset: "l_name". in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 35
DEBUG - 2015-07-11 21:00:27 --> Notice - Field with this name exists already in this fieldset: "f_name". in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 35
INFO - 2015-07-11 21:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:02:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:02:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:02:10 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 21:02:10 --> Notice - Unknown key after which to insert the new value into the array. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 376
ERROR - 2015-07-11 21:02:10 --> Error - Field "name" does not exist in this Fieldset. Field "f_name" can not be added. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 378
INFO - 2015-07-11 21:02:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:02:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:02:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:06:47 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 21:06:47 --> Notice - Unknown key after which to insert the new value into the array. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 376
ERROR - 2015-07-11 21:06:47 --> Error - Field "l_name_kana" does not exist in this Fieldset. Field "f_name" can not be added. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 378
INFO - 2015-07-11 21:07:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:07:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:07:05 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 21:07:05 --> Notice - Unknown key after which to insert the new value into the array. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 376
ERROR - 2015-07-11 21:07:05 --> Error - Field "l_name_kana" does not exist in this Fieldset. Field "f_name" can not be added. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\fieldset.php on line 378
INFO - 2015-07-11 21:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:07:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:07:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 21:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:07:53 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 21:07:54 --> Notice - Invalid rule "only_kanakana" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 21:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/952ad349c8ec158b57e63f16170586af27446b4c"
INFO - 2015-07-11 21:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:11:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 21:11:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:11:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:11:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 21:11:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:11:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 21:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 21:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 21:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:45:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 22:45:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:45:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:45:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-07-11 22:45:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:45:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-11 22:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 22:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 22:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:55:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 22:55:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:55:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:55:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 22:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 22:56:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 22:56:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 22:56:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:00:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:00:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:00:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:02:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:02:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:06:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:06:00 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-11 23:06:00 --> Notice - Field with this name exists already in this fieldset: "f_name". in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth.php on line 138
INFO - 2015-07-11 23:06:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:06:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:06:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:09:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:19:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:19:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:19:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:20:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:20:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:20:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-11 23:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:22:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-11 23:22:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:22:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:22:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/d50c5be8b612d91fc2b3549ec3af2aed3e9a62ee"
INFO - 2015-07-11 23:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:22:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-11 23:22:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:22:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-11 23:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:22:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_completion"
INFO - 2015-07-11 23:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:27:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:27:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:27:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:27:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:27:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:27:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-07-11 23:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:31:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:31:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:31:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:34:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:34:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:34:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:35:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:35:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:35:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-07-11 23:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-11 23:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:35:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:35:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:35:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:49:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:49:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:49:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:50:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:50:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:53:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:53:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:53:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:54:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:54:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:54:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-11 23:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-11 23:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-11 23:54:55 --> Fuel\Core\Request::execute - Setting main Request
