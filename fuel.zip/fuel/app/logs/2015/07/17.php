<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-17 18:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:29:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-17 18:29:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:29:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-17 18:30:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:30:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 18:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 18:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:30:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 18:30:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-17 18:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-17 18:30:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:30:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-17 18:30:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:30:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:31:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 18:31:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:31:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 18:31:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 18:31:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 18:31:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:20:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:20:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:20:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-17 19:20:09 --> Fatal Error - Using $this when not in object context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 25
INFO - 2015-07-17 19:29:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:29:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/logout"
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-17 19:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:29:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:31:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:31:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:31:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:39:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_profile"
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_deteil_profile"
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_profile"
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:40:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:40:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:40:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:40:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:40:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:40:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:40:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:49:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:49:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:49:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 19:49:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 19:49:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 19:49:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:10:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:10:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:10:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 20:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:10:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:10:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:10:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:10:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 20:10:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:10:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:10:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:10:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:10:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-17 20:11:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-17 20:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 20:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-17 20:11:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-17 20:11:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:11:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:11:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:11:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:11:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:12:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 20:12:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:12:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:12:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-17 20:12:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:12:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-17 20:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-17 20:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-17 20:12:28 --> Fuel\Core\Request::execute - Setting main Request
