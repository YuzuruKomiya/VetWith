<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-22 18:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-22 18:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:38:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-22 18:38:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:38:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-22 18:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:38:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 18:38:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:38:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 18:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:48:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 18:48:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:48:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 18:50:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 18:50:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 18:50:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:33:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:33:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:33:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:49:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:49:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:49:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:51:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:51:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:51:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:52:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:52:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:52:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:52:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:52:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:52:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:53:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:53:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:53:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:55:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:55:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:55:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:55:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:55:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:55:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:57:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:57:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:57:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:57:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:58:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 19:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 19:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 19:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:03:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:03:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:03:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:06:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:06:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:06:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:06:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:06:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:09:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:09:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:09:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:13:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:13:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:13:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:14:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:14:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 20:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 20:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 20:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:05:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:05:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:05:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:20:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:20:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:20:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:23:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:33:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:33:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:33:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:33:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:33:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:33:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:47:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:47:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:47:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 21:55:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 21:55:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 21:55:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:07:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:07:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:07:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:22:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:22:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:22:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:23:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:23:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:23:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:34:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:34:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:34:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:34:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:34:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:34:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:34:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:34:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:34:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-22 22:34:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-22 22:34:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-22 22:34:46 --> Fuel\Core\Request::execute - Setting main Request
