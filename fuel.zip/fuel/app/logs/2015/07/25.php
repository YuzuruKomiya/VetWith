<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-25 14:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-25 14:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:05:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-25 14:05:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:05:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:05:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 14:05:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:05:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-25 14:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-25 14:18:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-25 14:18:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-25 14:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-07-25 14:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-25 14:18:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-25 14:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 14:18:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 14:18:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 14:18:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 15:04:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 15:04:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 15:04:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 15:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 15:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 15:32:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 15:32:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 15:32:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 15:32:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 15:33:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 15:33:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 15:33:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 15:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 15:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 15:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:06:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:06:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:06:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:06:52 --> Notice - Undefined index: working_hour in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 47
INFO - 2015-07-25 16:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:07:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:07:41 --> Notice - Undefined index: operation in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 12
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer"
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-25 16:08:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-25 16:08:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:08:43 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:08:43 --> Notice - Undefined index: preuser_id in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 78
INFO - 2015-07-25 16:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:23:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:23:55 --> Notice - Undefined index: operation in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 12
INFO - 2015-07-25 16:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:24:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:24:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:24:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:24:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:24:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:25:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:25:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:25:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:25:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:25:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:25:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:25:12 --> Notice - Undefined index: operation in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 12
INFO - 2015-07-25 16:25:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:25:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:25:37 --> Notice - Undefined index: operation in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 12
INFO - 2015-07-25 16:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:25:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:25:42 --> Notice - Undefined index: realm in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 19
INFO - 2015-07-25 16:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:26:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:26:33 --> Notice - Undefined index: realm in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 19
INFO - 2015-07-25 16:26:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:26:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:26:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:26:41 --> Notice - Undefined index: realm in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 19
INFO - 2015-07-25 16:26:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:26:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:26:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 16:26:51 --> Notice - Undefined index: realm in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 19
INFO - 2015-07-25 16:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:29:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:29:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:29:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:30:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 16:30:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:30:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:30:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:30:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:30:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:30:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:30:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:30:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 16:31:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 16:31:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 16:31:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:12:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:12:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:12:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 18:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:13:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:13:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:13:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 18:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:38:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:38:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:38:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:38:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:38:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:38:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:50:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 18:50:45 --> Parsing Error - syntax error, unexpected '}' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 43
INFO - 2015-07-25 18:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:51:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:51:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:51:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:51:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:51:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:52:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:52:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:52:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:52:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 18:52:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:52:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:52:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 18:52:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:52:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 18:52:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 18:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 18:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:00:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:00:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:00:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 19:00:10 --> Fatal Error - Maximum function nesting level of '100' reached, aborting! in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 42
INFO - 2015-07-25 19:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:05:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 19:05:19 --> Notice - Undefined variable: converted_text in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 55
INFO - 2015-07-25 19:05:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:05:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:05:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:11:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:11:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:11:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:11:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:11:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:11:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:11:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:11:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:11:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:11:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:11:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:11:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:26:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:26:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 19:26:39 --> Warning - array_map() expects parameter 1 to be a valid callback, class 'Mypage' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 44
INFO - 2015-07-25 19:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:33:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:33:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:33:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:35:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:35:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:35:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:35:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:35:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:35:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:35:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:35:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:35:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:35:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:35:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:38:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:38:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:38:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:39:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 19:39:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:39:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 19:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 19:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 19:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 20:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 20:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 20:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:01:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 20:01:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:01:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 20:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 20:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:07:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-25 20:07:08 --> Warning - Illegal string offset 'operation' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_confirm.php on line 15
INFO - 2015-07-25 20:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 20:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 20:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 20:10:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 20:10:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 20:10:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:09:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:09:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:09:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:13:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:25:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:25:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:25:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:25:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:25:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:25:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:25:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:32:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:32:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:32:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:32:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:32:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:32:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:33:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:33:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:33:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:36:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 21:36:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:36:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 21:36:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 21:36:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 21:36:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 22:00:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-25 22:00:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 22:00:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-25 22:00:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-25 22:00:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-25 22:00:09 --> Fuel\Core\Request::execute - Setting main Request
