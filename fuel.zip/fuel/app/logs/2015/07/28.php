<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-28 13:28:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-28 13:28:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:28:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 13:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 13:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:29:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-28 13:29:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:29:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:29:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 13:29:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:29:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-28 13:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:30:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 13:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 13:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:30:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 13:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 13:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 13:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:10:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:17:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:18:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:29:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 14:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:32:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:33:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:35:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/assets/img/clinic"
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/assets/img/clinic"
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/assets/img/clinic"
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index"
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 14:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 14:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 14:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:03:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:03:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:03:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 15:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:34:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 15:34:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:34:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:34:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 15:34:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:34:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-07-28 15:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 15:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:42:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:42:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:42:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:42:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:42:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:43:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:43:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:43:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:43:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:43:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:43:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:43:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:43:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:43:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:43:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:43:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:43:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:45:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:45:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:45:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:45:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-28 15:45:17 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Update::from() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 109
INFO - 2015-07-28 15:47:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 15:47:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:47:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 15:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 15:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 15:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 15:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:00:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:00:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:00:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 16:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:00:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 16:00:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:00:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:08:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 16:08:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:08:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-28 16:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-28 16:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:09:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:09:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:09:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 16:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:11:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-07-28 16:11:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:11:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-07-28 16:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 16:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 16:11:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 16:11:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 16:11:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 20:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 20:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 20:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 20:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 20:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-28 20:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 20:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 20:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 20:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 20:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 23:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-28 23:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-28 23:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:15:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 23:15:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:15:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:25:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-28 23:25:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:25:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-28 23:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 23:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-28 23:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-07-28 23:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-28 23:57:26 --> Fuel\Core\Request::execute - Setting main Request
