<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-20 12:27:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:27:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:27:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-20 12:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:34:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-20 12:34:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:34:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:37:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-20 12:37:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:37:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-20 12:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-20 12:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:37:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:37:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:37:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:37:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:48:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:48:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:48:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:49:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:49:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:49:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:50:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:50:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:50:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 12:55:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 12:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 12:55:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:38:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:38:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:38:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:38:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:38:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:38:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:40:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:44:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:44:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:44:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:44:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:44:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:45:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:45:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:45:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:45:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:45:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:45:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:49:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:49:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:49:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:49:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:49:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:49:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:50:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:50:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:50:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:54:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:54:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:54:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:55:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:55:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:55:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:55:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:55:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:56:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:56:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:56:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:57:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:57:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:57:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:58:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:58:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:58:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 13:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 13:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 13:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:00:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:00:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:00:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:02:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:02:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:02:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:02:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:02:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:02:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:02:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:02:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:02:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 14:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 14:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 14:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:04:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:04:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:04:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:07:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:07:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:07:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:08:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:08:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:08:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:09:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:10:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:10:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:10:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:11:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:11:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:11:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:11:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:11:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:11:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:12:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:12:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:12:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:14:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:14:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:16:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:16:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:19:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:19:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:19:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:19:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:19:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:19:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:35:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:35:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:35:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:35:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:35:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:35:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:35:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:35:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:35:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 15:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 15:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 15:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:05:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:05:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:05:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:06:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:06:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:06:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:16:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:16:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:16:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:18:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:18:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:18:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:19:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:19:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:19:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:19:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:19:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:19:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:19:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:19:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:19:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:32:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:32:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:32:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:32:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:32:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:32:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:32:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:33:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:33:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:33:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:35:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:35:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:35:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 16:35:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 16:35:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 16:35:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:21:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:21:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:21:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:22:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:22:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:22:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 17:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 17:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 17:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "error/invalid/unko"
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-20 21:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-20 21:34:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-20 21:34:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:34:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:35:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:35:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:35:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:59:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:59:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:59:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:59:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:59:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 21:59:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 21:59:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 21:59:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 22:09:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 22:09:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 22:09:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 22:12:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 22:12:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 22:12:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 22:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 22:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 22:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-20 22:23:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-20 22:23:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-20 22:23:08 --> Fuel\Core\Request::execute - Setting main Request
