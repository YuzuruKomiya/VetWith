<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-02 15:46:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-02 15:46:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 15:46:43 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 15:46:43 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-02 15:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 15:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 15:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 15:53:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 15:53:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 15:53:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 15:53:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 15:53:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 15:53:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 15:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 15:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 15:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:12:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:12:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:12:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 17:12:50 --> Fatal Error - Call to undefined method Fieldsetplus\Fieldsetplus::field_date_select() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 142
INFO - 2015-07-02 17:16:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:16:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:16:14 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 17:16:14 --> Fatal Error - Call to undefined method Fieldsetplus\Fieldsetplus::field_date_select() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 142
INFO - 2015-07-02 17:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:17:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 17:17:20 --> Error - Package 'viewforms' could not be found at 'C:/Users/yuduru/work/fuelphp/fuel/packages/viewforms/' in C:\Users\yuduru\work\fuelphp\fuel\core\classes\package.php on line 89
INFO - 2015-07-02 17:17:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:17:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:17:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 17:17:27 --> Fatal Error - Call to undefined method Fieldsetplus\Fieldsetplus::field_date_select() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 142
INFO - 2015-07-02 17:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:40:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:40:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:40:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:43:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:43:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:43:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:44:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:44:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:44:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 17:59:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 17:59:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 17:59:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:08:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:08:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:08:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:08:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:08:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:08:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:09:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:09:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:09:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:10:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:10:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:10:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:10:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:10:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:10:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:11:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:11:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:11:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:12:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:12:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:12:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:14:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:14:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:14:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:14:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:14:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:17:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:17:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:17:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:21:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:21:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:21:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:21:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:33:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:33:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/invite"
INFO - 2015-07-02 18:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:50:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:50:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:50:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:58:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 18:58:22 --> Runtime Recoverable error - Argument 3 passed to Fieldsetplus\Fieldsetplus::add() must be of the type array, string given, called in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 35 and defined in C:\Users\yuduru\work\fuelphp\fuel\packages\fieldsetplus\classes\fieldsetplus.php on line 46
INFO - 2015-07-02 18:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 18:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:58:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 18:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:58:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 18:58:49 --> Notice - Undefined index: b_year in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register_confirm.php on line 55
INFO - 2015-07-02 18:59:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 18:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 18:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:30:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:30:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:30:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:30:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-02 19:30:15 --> Notice - Undefined variable: date in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\student\auth\register.php on line 43
INFO - 2015-07-02 19:30:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:30:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:30:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:31:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:31:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:31:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:31:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:31:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:31:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:35:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:35:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:35:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:37:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:37:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:37:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:37:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:37:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:37:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:45:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:45:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:45:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:47:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:47:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13c89786f5ab3fc713cffe1e7d535c7d2527f7e6"
INFO - 2015-07-02 19:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 19:49:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 19:49:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 19:49:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-02 23:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-02 23:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-02 23:39:19 --> Fuel\Core\Request::execute - Setting main Request
