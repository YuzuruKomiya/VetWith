<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-27 11:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-27 11:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 11:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 11:48:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-27 11:48:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 11:48:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 11:48:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 11:48:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 11:48:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 11:48:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 11:48:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 11:48:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:39:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 15:39:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:39:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:39:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-27 15:39:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:39:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:39:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-27 15:39:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:39:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:39:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 15:39:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:39:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:39:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:39:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:39:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 15:39:44 --> 1054 - Unknown column 'username' in 'where clause' [ SELECT * FROM `offers` WHERE `username` = 'bbbbbbbb' ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-07-27 15:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:40:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 15:40:12 --> Warning - mysqli_result::data_seek() expects parameter 1 to be long, string given in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\result.php on line 36
INFO - 2015-07-27 15:43:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:43:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:43:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:43:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:43:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:50:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:50:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:51:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:51:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:51:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:51:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:52:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:52:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:52:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:52:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:52:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:52:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 15:53:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 15:53:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 15:53:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:18:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:18:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:21:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:21:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:21:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:23:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:23:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:23:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:41:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:42:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:42:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:42:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:46:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 16:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 16:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 16:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:05:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:05:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:05:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:05:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:05:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:05:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:05:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:13:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 17:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:15:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:15:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:15:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:15:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 17:15:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:15:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 17:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:38:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:38:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:38:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 17:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:40:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:40:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:56:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 17:56:21 --> Notice - Undefined variable: offer_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_register.php on line 13
INFO - 2015-07-27 17:57:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:57:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:57:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 17:57:49 --> Notice - Undefined variable: offer_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_register.php on line 13
INFO - 2015-07-27 17:57:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 17:57:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:57:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 17:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 17:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:58:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 17:58:08 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-07-27 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 17:59:58 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-27 17:59:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 18:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:00:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:00:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:00:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:00:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/register_offer"
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/register_offer"
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/register_offer"
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:00:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:13 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-27 18:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 18:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:01:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:01:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/register_offer"
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:01:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:01:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:01:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:02:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:02:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:02:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 18:02:29 --> Notice - Undefined variable: input in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 607
INFO - 2015-07-27 18:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:02:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-27 18:02:59 --> Fatal Error - Call to undefined method Model_Clinic_Mypage::offer_register() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 620
ERROR - 2015-07-27 18:02:59 --> Fatal Error - Call to undefined method Model_Clinic_Mypage::offer_register() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 620
INFO - 2015-07-27 18:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-27 18:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:04:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-27 18:04:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:04:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:04:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:04:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:04:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-27 18:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:06:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:06:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:06:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:06:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:06:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:06:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:06:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:09:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:09:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:09:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:09:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:09:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:11:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:11:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:11:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:11:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:13:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:13:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:13:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:13:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:13:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:13:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:14:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:14:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:14:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 18:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 18:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 18:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 18:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 19:30:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 19:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 19:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 19:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 19:30:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 19:30:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 19:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 19:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-27 19:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 19:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-27 19:30:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-27 19:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-27 19:30:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-07-27 19:30:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-27 19:30:57 --> Fuel\Core\Request::execute - Setting main Request
