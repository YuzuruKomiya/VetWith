<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-06 22:00:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/invite"
INFO - 2015-07-06 22:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/send_invitation"
INFO - 2015-07-06 22:02:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:02:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:03:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:03:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:03:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:03:11 --> Notice - Use of undefined constant numeric - assumed 'numeric' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 125
INFO - 2015-07-06 22:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:03:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:03:45 --> Notice - Use of undefined constant numeric - assumed 'numeric' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 132
INFO - 2015-07-06 22:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:03:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:03:47 --> Notice - Use of undefined constant numeric - assumed 'numeric' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 132
INFO - 2015-07-06 22:03:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:03:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:03:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:03:58 --> Notice - Undefined variable: prefecture in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 189
INFO - 2015-07-06 22:04:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:04:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:04:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:05:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:05:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:05:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:06:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:06:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:06:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:08:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-06 22:08:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:08:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:09:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:09:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:09:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:12:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:12:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:12:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:13:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:13:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:13:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:13:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:13:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:13:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:15:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:15:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:15:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:16:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:16:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:16:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:16:29 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 363
INFO - 2015-07-06 22:16:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:16:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:16:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:16:39 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 363
INFO - 2015-07-06 22:18:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:18:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:18:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:18:07 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 363
INFO - 2015-07-06 22:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_confirm"
INFO - 2015-07-06 22:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:56:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-06 22:56:18 --> Notice - Undefined index: birthday in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth\clinicregister.php on line 363
INFO - 2015-07-06 22:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 22:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 22:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 22:57:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-06 23:02:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register/ec071d7a007ad2d4e3ff5db5e013fe70b37447e2"
INFO - 2015-07-06 23:02:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-06 23:02:53 --> Fuel\Core\Request::execute - Setting main Request
