<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-26 16:09:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-26 16:09:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:09:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 16:09:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:09:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 16:09:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 16:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 16:10:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-26 16:10:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 16:10:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-26 17:48:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:48:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-26 17:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:49:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-26 17:49:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:49:05 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
DEBUG - 2015-07-26 17:49:05 --> Notice - Invalid rule "no_tab" passed to Validation, not used. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\validation.php on line 469
INFO - 2015-07-26 17:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-26 17:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:55:48 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-07-26 17:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:55:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 17:55:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:55:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:55:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-07-26 17:55:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:55:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 17:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-07-26 17:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 17:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 19:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 19:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 19:29:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 19:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 19:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:29:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 19:29:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:29:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 19:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:30:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:30:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 19:30:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:30:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:30:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-07-26 19:30:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:30:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 19:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 19:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 19:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 23:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-07-26 23:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 23:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-26 23:17:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-26 23:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-26 23:17:45 --> Fuel\Core\Request::execute - Setting main Request
