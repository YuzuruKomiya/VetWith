<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-01 14:29:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-01 14:29:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:29:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:29:41 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 14:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-01 14:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:29:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:29:41 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 14:29:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/unko"
INFO - 2015-07-01 14:29:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:29:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:29:48 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 14:29:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/deleted"
INFO - 2015-07-01 14:29:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:29:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:29:52 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/null"
INFO - 2015-07-01 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:29:57 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 14:30:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 14:30:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:30:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 14:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:30:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 14:30:50 --> Warning - Missing argument 1 for Controller_Student_Auth_StudentRegister::forge_register_form(), called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 290 and defined in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth\studentregister.php on line 31
INFO - 2015-07-01 14:42:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:42:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:42:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 14:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 14:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 14:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 14:59:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 14:59:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 14:59:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 15:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 15:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 15:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 15:01:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 15:01:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 15:01:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 15:01:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 15:01:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 15:01:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:19:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:19:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:19:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:28:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:28:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:28:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:28:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:28:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:28:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 16:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 16:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 16:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:05:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:05:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:05:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 17:05:56 --> Notice - Undefined index: s_email in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register_confirm.php on line 45
INFO - 2015-07-01 17:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:06:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 17:06:32 --> Notice - Undefined index: univsersity in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\auth\register_confirm.php on line 50
INFO - 2015-07-01 17:07:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:07:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:07:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:09:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:09:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:09:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:10:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:11:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:11:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:11:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:11:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 17:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:19:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 17:19:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:19:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:19:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:19:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:24:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 17:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 17:28:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-01 17:28:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 17:28:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:21:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 18:21:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:21:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:21:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:21:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:21:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/13a4daf0cd29f2ea8b3b0b5b55dc6d54da7936cb"
INFO - 2015-07-01 18:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:22:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-01 18:22:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 18:22:44 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 18:22:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:22:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:22:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:22:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:22:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register"
INFO - 2015-07-01 18:22:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:22:54 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 18:22:54 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
INFO - 2015-07-01 18:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register_confirm"
INFO - 2015-07-01 18:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-01 18:28:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentregister/register/pp"
INFO - 2015-07-01 18:28:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-01 18:28:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-01 18:28:57 --> 本登録エラー: 無効なURLです。Controller_Student_Auth_StudentRegister::action_register
