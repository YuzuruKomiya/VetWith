<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-07-09 10:12:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:12:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic"
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:12:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-09 10:12:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-09 10:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:13:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/logout"
INFO - 2015-07-09 10:13:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:13:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-07-09 10:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:19:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-09 10:19:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:19:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-09 10:19:50 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-07-09 10:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-09 10:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:30:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-09 10:30:47 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-07-09 10:30:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-09 10:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:30:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-07-09 10:30:48 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-07-09 10:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-07-09 10:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:31:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:31:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register/9f182d7903065d41c999266b8f93fae7688c9f47"
INFO - 2015-07-09 10:31:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:31:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/register_confirm"
INFO - 2015-07-09 10:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicregister/register_completion"
INFO - 2015-07-09 10:36:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:36:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:45:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-09 10:45:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:45:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:45:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/clinicauth/login"
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:46:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:46:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-09 10:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:46:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-09 10:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:46:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-07-09 10:46:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:46:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-07-09 10:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-07-09 10:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-07-09 10:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-07-09 10:47:34 --> Fuel\Core\Request::execute - Setting main Request
