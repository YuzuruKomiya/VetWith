<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-11 00:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-11 00:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:00:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
INFO - 2015-08-11 00:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:01:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:01:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:01:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:01:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 00:01:12 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 00:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:01:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 00:01:19 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 00:06:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:06:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:06:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:06:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:06:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:06:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 00:06:13 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 00:11:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:11:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:11:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:15:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:15:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:15:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:15:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:15:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:15:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:15:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:15:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:15:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:15:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:15:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:15:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:17:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:17:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:17:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:17:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:17:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:17:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:17:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:17:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:17:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:18:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:18:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:18:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:18:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:18:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:18:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:40:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:40:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:40:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:43:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:44:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:44:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:45:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:45:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:45:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:46:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:48:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:48:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:48:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:48:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:48:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:48:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:51:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:51:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:51:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:52:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:52:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:52:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:52:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:52:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:52:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 00:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 00:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:54:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:55:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 00:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 00:59:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 00:59:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 00:59:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:00:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:03:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 01:04:52 --> Fatal Error - Call to a member function count() on integer in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 57
INFO - 2015-08-11 01:04:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:06:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:06:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:06:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 01:07:00 --> Fatal Error - Call to a member function count() on integer in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 57
INFO - 2015-08-11 01:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:10:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 01:10:20 --> Fatal Error - Call to a member function count() on integer in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 57
INFO - 2015-08-11 01:11:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:11:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:11:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:11:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:11:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:11:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:12:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:12:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:12:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:13:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 01:13:10 --> Fatal Error - Call to a member function count() on integer in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 57
INFO - 2015-08-11 01:18:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:18:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:18:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:18:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:18:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:18:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:18:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:18:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:18:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:18:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:18:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:19:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:19:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:19:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:19:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:19:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:19:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:20:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:20:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:20:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:20:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:20:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:20:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:20:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:23:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:25:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:25:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:25:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:25:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:25:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:25:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:25:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:26:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:26:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 01:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:26:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 01:26:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:26:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:45:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:45:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 01:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 01:45:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 01:45:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 01:45:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:01:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-11 02:01:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:01:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 02:17:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 02:17:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:17:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:43:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 02:43:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:43:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:43:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 02:43:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:43:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:43:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 02:43:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:43:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:43:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 02:43:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:43:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 02:43:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 02:43:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 02:43:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 02:43:47 --> Warning - mysqli::mysqli():  in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 129
INFO - 2015-08-11 15:08:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:08:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:08:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:09:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:09:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:09:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-11 15:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 15:10:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:10:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:10:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:10:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:10:12 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:15:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:15:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:15:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:15:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:15:05 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:17:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:17:59 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:18:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:18:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:18:40 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:24:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:24:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:24:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:29:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:29:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:29:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:29:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/check"
INFO - 2015-08-11 15:29:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:29:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:29:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:29:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:29:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:29:40 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:32:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:32:39 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:51:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:51:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:51:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:51:26 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:55:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:55:57 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:57:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:57:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:57:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:57:10 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:58:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:58:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:58:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:58:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:58:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:58:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:58:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:58:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:58:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 15:58:55 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 15:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:59:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 15:59:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:00:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 16:00:03 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:05:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:05:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:05:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:05:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 16:05:31 --> Warning - simplexml_load_string(): Entity: line 1: parser error : Start tag expected, '&lt;' not found in C:\Users\yuduru\work\fuelphp\fuel\core\classes\format.php on line 424
INFO - 2015-08-11 16:06:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:06:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:06:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:07:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:07:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:07:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:07:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:07:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:07:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:08:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:09:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:09:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:09:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:09:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:09:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:09:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:10:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:10:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 16:10:20 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-11 16:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:16:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:16:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:16:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 16:16:22 --> Notice - Undefined index: offer_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 21
INFO - 2015-08-11 16:16:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:16:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:16:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:16:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:16:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:16:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:17:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:17:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:17:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 16:17:04 --> Notice - Undefined index: offer_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 21
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:18:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:19:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:19:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:19:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:19:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:19:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:19:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:21:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:21:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:21:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:21:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:21:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:33:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:33:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:33:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:34:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:34:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:34:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:37:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 16:37:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 16:37:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 16:37:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 17:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 17:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:07:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:07:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 17:07:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:07:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 17:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 17:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:38:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 17:38:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:38:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 17:39:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:39:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:40:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 17:40:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:40:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 17:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 17:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 17:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:30:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:30:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:30:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:30:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 18:30:53 --> Notice - Undefined variable: offer_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 24
INFO - 2015-08-11 18:31:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:31:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:31:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:31:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:31:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:31:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:44:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:44:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:44:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:44:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:44:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:44:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 18:46:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:46:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 18:46:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:46:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 18:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:00:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:01:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:01:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:01:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:01:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:01:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:03:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:03:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:03:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:05:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:05:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:05:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:05:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:05:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:05:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:05:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-11 19:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:23:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-11 19:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-11 19:24:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 19:24:07 --> Parsing Error - syntax error, unexpected end of file in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 5
INFO - 2015-08-11 19:24:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-11 19:24:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-11 19:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-11 19:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-11 19:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-11 19:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:24:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-11 19:24:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:24:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:27:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:27:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:27:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:27:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:27:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:27:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:27:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:29:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:29:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 19:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 19:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 19:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 19:29:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 19:29:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 19:29:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:52:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 20:52:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:52:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:53:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 20:53:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:53:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 20:54:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 20:54:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 20:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 20:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 20:54:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 20:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 20:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 20:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 20:55:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 22:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:13:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 22:13:13 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::count() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 24
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:16:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 22:16:20 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::count() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 24
INFO - 2015-08-11 22:16:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:16:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:16:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:16:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-11 22:16:32 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::count() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 24
INFO - 2015-08-11 22:17:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:17:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:17:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:17:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 22:17:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:17:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 22:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 22:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:18:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:18:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:29:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:32:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:32:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:32:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:32:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:37:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:41:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:41:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-11 22:41:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:41:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:41:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-11 22:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-11 22:45:40 --> Fuel\Core\Request::execute - Setting main Request
