<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-05 13:07:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:14:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:14:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:14:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-05 13:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:16:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:16:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:16:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:16:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:16:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:16:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-05 13:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:54:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:54:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:54:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-05 13:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:55:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-05 13:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:55:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 13:55:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:55:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 13:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-05 13:55:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 13:55:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 14:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 14:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 14:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 14:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 14:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 14:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
ERROR - 2015-08-05 15:38:21 --> Parsing Error - syntax error, unexpected ';' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 73
INFO - 2015-08-05 15:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:38:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:38:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:38:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:38:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:38:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:38:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:39:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:39:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:39:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:40:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:40:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:40:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:41:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:41:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:41:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:41:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:41:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:41:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:42:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:42:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:42:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-05 15:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:51:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:51:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 15:57:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 15:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 15:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:05:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 16:05:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:05:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-05 16:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-05 16:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:08:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:08:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:08:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:12:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:12:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:12:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:12:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:12:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:12:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:12:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:12:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:12:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:14:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:14:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:14:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:17:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:17:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:17:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:18:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:18:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:18:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:19:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:19:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:19:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:19:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:19:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:19:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:19:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:19:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:19:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:19:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:19:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:19:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:24:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:24:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:24:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 16:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:25:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:25:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:25:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:25:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:25:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:25:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:39:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:39:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-05 16:39:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:39:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-05 16:39:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:39:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:49:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:49:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:49:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:49:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:49:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:49:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:56:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-05 16:56:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:56:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 16:57:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 16:57:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 16:57:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 17:12:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-05 17:12:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 17:12:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 17:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 17:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 17:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-05 21:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:18:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-05 21:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:18:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-05 21:18:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:18:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:18:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-05 21:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:18:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-05 21:18:47 --> Fatal Error - Call to undefined method Fuel\Core\Fieldset_Field::set_config() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 383
INFO - 2015-08-05 21:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:39:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:47:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:47:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:47:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 21:57:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 21:57:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 21:57:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-05 22:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_image"
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:50:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:51:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:51:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:51:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:51:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:51:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:57:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:57:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:57:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:57:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:57:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:57:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 22:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 22:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 22:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-05 23:06:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-05 23:06:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-05 23:06:53 --> Fuel\Core\Request::execute - Setting main Request
