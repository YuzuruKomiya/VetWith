<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:02:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 00:02:35 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 00:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:03:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 00:03:45 --> Fatal Error - Cannot use object of type Fuel\Core\Database_Query_Builder_Select as array in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-04 00:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:04:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 00:04:29 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 00:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:04:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 00:04:53 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 00:05:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:05:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 00:05:01 --> Parsing Error - syntax error, unexpected '?>' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:05:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:06:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 00:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 12:55:35 --> Notice - Undefined index: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 78
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:55:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:56:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:57:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 12:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:01:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:02:24 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 78
INFO - 2015-08-04 13:02:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:02:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:02:31 --> Warning - Illegal string offset 'l_name' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 78
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:02:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:06:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:06:36 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 13:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:07:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:07:00 --> Notice - Undefined variable: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:57:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:57:45 --> Notice - Undefined index: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-04 13:57:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:57:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:57:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 13:57:52 --> Notice - Undefined index: name in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 13:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:03:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:03:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:03:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:03:55 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 77
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:04:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:09:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:09:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:10:13 --> Warning - Illegal string offset 'prefecture' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 13
INFO - 2015-08-04 14:10:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:10:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:23 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:10:23 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 13
INFO - 2015-08-04 14:10:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:10:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:10:31 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 13
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:10:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:13:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:14:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:14:41 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 75
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:17:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:17:16 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 77
INFO - 2015-08-04 14:17:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:17:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:17:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:17:40 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 77
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:43 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:19:43 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 79
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:19:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:20:26 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 79
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:20:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:21:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:23:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:27:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:27:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:27:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:27:38 --> Notice - unserialize(): Error at offset 6 of 960 bytes in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 9
INFO - 2015-08-04 14:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:27:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:27:46 --> Notice - unserialize(): Error at offset 6 of 960 bytes in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 9
INFO - 2015-08-04 14:28:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:28:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:28:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:28:53 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 13
INFO - 2015-08-04 14:28:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:28:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:28:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:28:58 --> Parsing Error - syntax error, unexpected '?>' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 13
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:29:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:31:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:31:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:31:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:31:48 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 75
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:32:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:33:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:33:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:42:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:42:17 --> Notice - Undefined variable: id in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 4
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:54:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:54:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:54:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 14:54:47 --> Notice - Undefined index: catchcopy in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 14:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:22:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-04 16:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:36:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 16:36:11 --> 1054 - Unknown column 'c_username' in 'where clause' [ SELECT * FROM `clinics` WHERE `c_username` = '5' ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:37:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:37:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:37:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:39:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:39:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:41:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 16:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 16:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 16:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:02:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:02:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:02:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:02:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers6"
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 17:03:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 17:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 17:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:04:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:13:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/hospital/hospital"
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:17:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 17:17:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:17:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/hospital/hospital"
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:19:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:20:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:23:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:24:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 17:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:25:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:25:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:29:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:29:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:29:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:29:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:29:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:29:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:32:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:32:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:32:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:33:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:33:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:33:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:46:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:46:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:46:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:49:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:49:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:49:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:49:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:49:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:49:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:50:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:50:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:50:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:50:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:50:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:50:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:53:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:53:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:53:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:54:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:54:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:54:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:56:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:56:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:56:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:58:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:58:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:58:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 17:58:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 17:58:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 17:58:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 18:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:06:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:06:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:06:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/hospital/hospital"
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:07:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:07:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:07:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:11:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:11:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:11:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:12:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:12:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:12:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:12:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:12:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:12:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:13:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:13:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:13:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:13:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:13:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:13:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:14:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:14:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:14:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:14:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:14:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:14:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:15:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:15:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:15:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:18:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:18:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:18:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:19:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:19:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:19:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:19:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:19:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:19:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:20:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:20:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:20:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:21:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:23:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:23:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:23:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:23:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:23:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:23:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:23:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 18:23:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:23:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:29:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:29:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:29:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:30:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:30:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:30:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:30:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:30:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:30:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:38:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:38:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:38:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:38:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:38:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:38:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:39:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:39:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:39:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:39:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:39:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:39:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:40:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:40:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:40:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:40:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:40:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:40:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 18:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 18:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:42:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:42:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:42:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 18:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:43:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 18:43:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:43:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:46:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 18:46:42 --> Error - The requested view could not be found: search.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-04 18:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:46:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 18:46:55 --> Error - The requested view could not be found: offer/search.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-04 18:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:47:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 18:47:02 --> Notice - Undefined variable: test in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\search.php on line 3
INFO - 2015-08-04 18:47:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:47:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:47:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:47:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:47:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:47:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:47:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:47:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:47:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:47:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 18:48:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 18:48:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 18:48:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:04:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:04:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:04:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:04:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:04:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:04:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:04:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:04:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:04:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:06:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:06:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:06:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:06:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:06:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:06:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:07:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:07:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:07:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:07:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:07:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:07:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:07:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:07:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:07:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:07:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:07:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:09:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:09:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:09:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:11:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:11:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:11:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:12:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:12:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:12:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:25:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:25:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:25:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:26:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:26:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:26:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:26:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:26:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:26:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:26:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:29:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:29:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:29:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:30:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:30:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:30:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:31:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:31:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:31:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:32:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:32:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:32:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:32:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:32:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:32:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:35:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:35:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:35:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:36:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:36:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:36:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:37:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:37:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:37:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:37:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:37:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:40:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:40:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:40:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:42:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:42:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:42:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:43:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:43:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:43:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:44:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:45:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:45:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:45:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:45:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:45:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:45:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:46:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:46:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:46:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:47:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:47:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:47:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:48:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:49:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:49:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:49:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:49:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:50:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:50:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:50:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:50:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:50:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:50:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-04 19:50:57 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-04 19:51:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 19:51:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:51:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 19:52:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 19:52:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 19:52:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:14:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 23:14:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:14:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:15:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 23:15:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:15:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-04 23:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 23:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:22:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-04 23:22:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:22:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-04 23:22:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:22:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-04 23:22:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-04 23:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-04 23:22:37 --> Fuel\Core\Request::execute - Setting main Request
