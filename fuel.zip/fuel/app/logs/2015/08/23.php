<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-23 13:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 13:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:31:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 13:31:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:31:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:33:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:33:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:33:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:35:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:35:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:35:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 13:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-23 13:39:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-23 13:39:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-23 13:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-23 13:39:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:39:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-23 13:39:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:39:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:40:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:40:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:55:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:55:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:55:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:58:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:58:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:58:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:58:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 13:58:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 13:58:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 13:58:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:19:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:19:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:19:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-23 14:19:05 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\views\contact\index.php on line 16
INFO - 2015-08-23 14:20:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:20:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:20:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:22:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:22:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:22:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:23:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:23:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:23:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:29:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-23 14:29:11 --> Parsing Error - syntax error, unexpected ':' in C:\Users\yuduru\work\fuelphp\fuel\app\views\contact\index.php on line 19
INFO - 2015-08-23 14:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 14:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 14:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:49:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-23 14:49:51 --> Fatal Error - Cannot access protected property Fuel\Core\Fieldset::$validation in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\contact.php on line 60
INFO - 2015-08-23 14:50:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-23 14:50:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:50:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:51:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 14:51:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:51:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-23 14:51:00 --> Fatal Error - Cannot access protected property Fuel\Core\Fieldset::$validation in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\contact.php on line 60
INFO - 2015-08-23 14:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 14:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 14:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 14:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 14:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 15:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 15:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 15:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 15:06:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 15:06:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 15:06:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 15:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 15:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 15:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:37:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:37:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:37:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-23 17:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:38:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-23 17:38:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:38:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:38:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 17:38:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:38:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-23 17:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:40:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:42:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:42:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:42:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:43:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:43:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:43:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:43:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:43:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:43:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 17:44:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 17:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 17:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 19:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 19:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 19:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:25:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 19:25:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:25:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-23 19:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-23 19:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:43:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-23 19:43:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:43:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-23 19:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 19:43:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 19:43:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 19:43:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:34:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:34:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:34:30 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:34:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:34:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:34:33 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:34:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:37:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:17 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:37:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:37:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:23 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:37:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:37:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:37 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:37:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:38 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:37:42 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:38:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:09 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:38:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:38:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:29 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-23 23:38:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:38:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-23 23:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-23 23:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:39:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:39:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:39:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:41:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-23 23:41:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:41:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-23 23:41:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-23 23:41:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-23 23:41:03 --> Fuel\Core\Request::execute - Setting main Request
