<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-02 14:49:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-08-02 14:49:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:49:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 14:49:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-02 14:49:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:49:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 14:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-02 14:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 14:53:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 14:53:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:53:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 14:53:48 --> Warning - Missing argument 1 for Model_Offers::search(), called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 44 and defined in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 82
INFO - 2015-08-02 14:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 14:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:53:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 14:53:49 --> Warning - Missing argument 1 for Model_Offers::search(), called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 44 and defined in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 82
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:54:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 14:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-02 14:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 14:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:15:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 15:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:17:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 15:17:18 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::as_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 117
INFO - 2015-08-02 15:19:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:19:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:19:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 15:19:43 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::as_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 117
INFO - 2015-08-02 15:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 15:27:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-02 15:27:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:27:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 15:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:50:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 15:50:06 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::count() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 124
INFO - 2015-08-02 15:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-02 15:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 15:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-02 16:00:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-02 16:00:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 16:00:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 16:00:13 --> Parsing Error - syntax error, unexpected '}', expecting identifier (T_STRING) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 132
INFO - 2015-08-02 16:00:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-02 16:00:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 16:00:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-02 16:00:46 --> Parsing Error - syntax error, unexpected '}', expecting identifier (T_STRING) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 132
INFO - 2015-08-02 16:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-02 16:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-02 16:00:50 --> Fuel\Core\Request::execute - Setting main Request
