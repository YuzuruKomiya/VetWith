<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-20 22:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:41:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:41:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:41:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:41:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:41:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:41:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:41:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:41:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:41:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:58:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:58:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:58:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 22:59:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 22:59:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 22:59:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:03:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:03:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:03:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-20 23:03:01 --> Notice - Use of undefined constant topcircleimage - assumed 'topcircleimage' in C:\Users\yuduru\work\fuelphp\fuel\app\views\index.php on line 58
INFO - 2015-08-20 23:03:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:03:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:03:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:03:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:03:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:03:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:08:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:08:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:08:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:10:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:10:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:10:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:15:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:15:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:15:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:15:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:15:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:15:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:17:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:17:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:17:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:17:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:17:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:18:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:18:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:18:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:18:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:18:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:18:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:34:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:36:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:37:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:37:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:37:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:37:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:37:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:37:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:38:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:38:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:38:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:39:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:39:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:41:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:41:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:41:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:52:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:52:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:52:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:52:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:52:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:52:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-20 23:56:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-20 23:56:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-20 23:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-20 23:56:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-20 23:56:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-20 23:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-20 23:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-20 23:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-20 23:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-20 23:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-20 23:57:28 --> Fuel\Core\Request::execute - Setting main Request
