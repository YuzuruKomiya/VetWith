<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-03 14:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-03 14:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers"
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:36:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-03 14:36:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:36:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:36:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:36:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:36:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:36:29 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 52
INFO - 2015-08-03 14:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:36:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:36:53 --> Notice - Undefined variable: pagination in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 3
INFO - 2015-08-03 14:37:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:37:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:37:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:40:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:40:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:40:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:40:45 --> Warning - Invalid argument supplied for foreach() in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 14:41:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:41:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:41:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:41:21 --> Parsing Error - syntax error, unexpected end of file in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 6
INFO - 2015-08-03 14:41:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:41:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:41:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:48:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:48:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:48:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:48:10 --> Fatal Error - Access to undeclared static property: Fuel\Core\Pagination::$per_page in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 57
INFO - 2015-08-03 14:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:51:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 14:51:05 --> Fatal Error - Access to undeclared static property: Fuel\Core\Pagination::$per_page in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 57
INFO - 2015-08-03 14:54:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:54:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:54:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/offers/search"
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 14:58:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 14:58:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 14:58:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:01:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:01:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:01:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:01:32 --> Parsing Error - syntax error, unexpected end of file, expecting ',' or ';' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 6
INFO - 2015-08-03 15:01:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:01:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:01:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:01:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:01:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:01:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:01:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:01:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:01:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:02:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:02:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:02:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:02:08 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 15:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:02:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:02:21 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 15:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:02:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:02:26 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 15:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:03:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:03:41 --> Warning - Invalid argument supplied for foreach() in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 15:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:06:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:06:31 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::get() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 57
INFO - 2015-08-03 15:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:11:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:11:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:11:25 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:11:25 --> Warning - Invalid argument supplied for foreach() in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 5
INFO - 2015-08-03 15:11:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:11:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:11:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/offers/search"
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:16:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:18:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:18:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:18:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:20:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:20:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:20:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:27:43 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:27:43 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = ('5') OR `id` = ('4')' at line 1 [ SELECT * WHERE `id` = ('5') OR `id` = ('4') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 15:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:28:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:28:28 --> 1064 - You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = ('5') OR `id` = ('4') LIMIT 1 OFFSET 0' at line 1 [ SELECT * WHERE `id` = ('5') OR `id` = ('4') LIMIT 1 OFFSET 0 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 15:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:29:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:29:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:29:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:46:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:46:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:46:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:47:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:48:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:48:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:48:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 15:48:48 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-03 15:49:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:49:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:49:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:49:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:49:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:49:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:49:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:49:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:49:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:50:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:50:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:50:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:50:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:50:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:50:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 15:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 15:51:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 15:51:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:07:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:07:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:07:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 16:07:41 --> Notice - Undefined variable: row in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 9
INFO - 2015-08-03 16:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:08:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:11:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 16:14:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:23:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:23:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:37:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:37:31 --> Runtime Recoverable error - Object of class Fuel\Core\Database_MySQLi_Result could not be converted to string in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\connection.php on line 504
INFO - 2015-08-03 17:40:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:40:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:40:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:40:14 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 10
INFO - 2015-08-03 17:41:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:41:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:41:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:41:47 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 12
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:43:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:43:11 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::as_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 124
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:44:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:44:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:44:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:44:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:47:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:49:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:49:37 --> Fatal Error - Call to undefined method Fuel\Core\Database_MySQLi_Result::as_assoc() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 123
INFO - 2015-08-03 17:50:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:50:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:50:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:50:38 --> Fatal Error - Call to undefined method Fuel\Core\Database_MySQLi_Result::as_assoc() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 123
INFO - 2015-08-03 17:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:51:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:51:05 --> Notice - Undefined variable: pagination in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 68
INFO - 2015-08-03 17:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:51:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:51:18 --> Notice - Undefined variable: test in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 3
INFO - 2015-08-03 17:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:51:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:51:29 --> Notice - Undefined variable: offers in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 6
INFO - 2015-08-03 17:51:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:51:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:51:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:51:34 --> Notice - Undefined variable: offers in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 7
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:52:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:56:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:57:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:57:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:57:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 17:57:38 --> 1241 - Operand should contain 1 column(s) [ SELECT * FROM `clinics` WHERE `id` = (('5'), ('4')) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 17:59:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:04:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:04:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:04:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:04:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:06:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:07:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:20:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:48:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:48:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:48:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:48:19 --> 1066 - Not unique table/alias: 'offers' [ SELECT * FROM `offers` LEFT JOIN `offers` ON (`clinics`.`username` = `offers`.`c_username`) WHERE `id` = ('4') OR `id` = ('5') ORDER BY `id` ASC LIMIT 1 OFFSET 1 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 18:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:49:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:49:18 --> 1052 - Column 'id' in where clause is ambiguous [ SELECT * FROM `offers` LEFT JOIN `clinics` ON (`offers`.`c_username` = `clinics`.`username`) WHERE `id` = ('4') OR `id` = ('5') ORDER BY `id` ASC LIMIT 1 OFFSET 1 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 18:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:49:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:49:46 --> 1052 - Column 'id' in where clause is ambiguous [ SELECT * FROM `offers` LEFT JOIN `clinics` ON (`offers`.`c_username` = `clinics`.`username`) WHERE `id` = ('4') OR `id` = ('5') ORDER BY `offers`.`id` ASC LIMIT 1 OFFSET 1 ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-03 18:50:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:50:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:50:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:50:13 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 70
INFO - 2015-08-03 18:51:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:51:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:51:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:51:05 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 68
INFO - 2015-08-03 18:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:55:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:55:59 --> Notice - Undefined index: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 68
INFO - 2015-08-03 18:56:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:56:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:56:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:56:10 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 41
INFO - 2015-08-03 18:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:56:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 18:56:24 --> Notice - Undefined index: realm in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 68
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 18:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 19:24:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 19:24:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 19:24:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 19:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:54:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 22:54:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:54:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:54:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 22:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 22:56:40 --> Notice - Undefined index: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 72
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 22:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:00:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:00:41 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:00:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:01:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:01:59 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 14
INFO - 2015-08-03 23:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:03:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:03:10 --> Notice - Undefined variable: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 14
INFO - 2015-08-03 23:03:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:03:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:03:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:03:40 --> Notice - Undefined variable: prefecture in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 14
INFO - 2015-08-03 23:04:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:04:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:05:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:05:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:06:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:08:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:08:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:08:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:08:18 --> Warning - Invalid argument supplied for foreach() in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 7
INFO - 2015-08-03 23:08:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:08:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:08:48 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-03 23:09:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:09:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:09:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:09:28 --> Notice - Undefined variable: unserialize in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:09:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:09:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:09:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:09:37 --> Warning - Illegal string offset 'c_username' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:21:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:25:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:26:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:26:16 --> Notice - Undefined index: profile_fieあlds in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:26:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:26:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:26:26 --> Notice - Undefined index: profile_fiealds in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:26:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:29:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:30:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:35:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:44:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:44:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:44:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:44:51 --> Warning - Illegal string offset 'prefecture' in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 11
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:45:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:45:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:45:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:45:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:47:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:47:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:47:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:47:39 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:48:03 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:48:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:48:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:48:05 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:49:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:23 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:49:23 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:49:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:50:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:50:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:53:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:53:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:53:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-03 23:53:56 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 74
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:54:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "image/hospital"
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-03 23:59:22 --> Fuel\Core\Request::execute - Setting main Request
