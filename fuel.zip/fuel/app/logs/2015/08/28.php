<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-28 12:41:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 12:41:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 12:41:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 12:51:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 12:51:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 12:51:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 14:59:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-28 14:59:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 14:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-28 14:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/6"
INFO - 2015-08-28 14:59:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 14:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/6"
INFO - 2015-08-28 14:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 14:59:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-28 14:59:42 --> Fatal Error - Using $this when not in object context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 298
INFO - 2015-08-28 15:03:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/6"
INFO - 2015-08-28 15:03:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:03:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/6"
INFO - 2015-08-28 15:03:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:03:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-28 15:03:38 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\submenu.php on line 10
INFO - 2015-08-28 15:05:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/6"
INFO - 2015-08-28 15:05:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:05:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:05:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/6"
INFO - 2015-08-28 15:05:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:05:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-28 15:05:34 --> Notice - Undefined variable: c_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\apply_completion.php on line 2
INFO - 2015-08-28 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/6"
INFO - 2015-08-28 15:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:06:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 15:06:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:06:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/6"
INFO - 2015-08-28 15:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 15:22:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 15:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 15:22:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-28 15:22:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 15:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:22:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 15:22:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:22:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 15:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 15:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 15:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 20:43:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:43:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-28 20:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-28 20:45:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-28 20:45:09 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-08-28 20:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 20:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-28 20:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 20:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-28 20:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-28 20:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:46:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-28 20:46:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:46:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-28 20:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:46:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:46:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 20:46:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:46:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 20:50:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-28 20:50:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-28 20:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-28 20:50:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:50:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/6"
INFO - 2015-08-28 20:50:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:50:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-28 20:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/6"
INFO - 2015-08-28 20:51:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/6"
INFO - 2015-08-28 20:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/6"
INFO - 2015-08-28 20:51:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-28 20:51:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 20:51:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 20:51:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 20:51:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 21:32:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-28 21:32:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-28 21:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-28 21:32:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-28 21:32:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-28 21:32:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-28 21:32:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-28 21:32:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-28 21:32:30 --> Fuel\Core\Request::execute - Setting main Request
