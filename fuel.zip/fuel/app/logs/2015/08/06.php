<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-06 13:22:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-06 13:22:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:22:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:22:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-06 13:22:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:22:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-06 13:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:31:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-06 13:31:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:31:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:31:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 13:31:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:31:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:40:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 13:40:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:40:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 13:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 13:46:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 13:46:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 13:46:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:16:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:16:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:16:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:20:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:20:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:20:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:21:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:22:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:22:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:22:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:42:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:42:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:42:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 14:48:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 14:48:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 14:48:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 15:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 15:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 15:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 15:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 15:58:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 15:58:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 16:00:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 16:00:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 16:00:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 16:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 16:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 16:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 16:01:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-06 16:01:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 16:01:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 16:01:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 16:01:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 16:01:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 19:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 19:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 19:00:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-06 19:00:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:00:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:00:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-06 19:00:45 --> Parsing Error - syntax error, unexpected '}' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 153
INFO - 2015-08-06 19:00:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-06 19:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 19:01:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 19:01:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 19:01:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 20:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-06 20:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 20:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/upload_images_completion"
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-06 20:25:35 --> Fuel\Core\Request::execute - Setting main Request
