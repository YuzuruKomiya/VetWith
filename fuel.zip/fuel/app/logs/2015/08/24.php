<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 14:34:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 14:37:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "check"
INFO - 2015-08-24 14:37:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 14:37:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 15:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:03:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:03:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:03:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:03:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 15:03:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:03:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:04:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:04:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:04:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:04:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 15:04:12 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
ERROR - 2015-08-24 15:04:12 --> Notice - Undefined variable: form in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\auth.php on line 267
INFO - 2015-08-24 15:04:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:04:53 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 15:04:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-24 15:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:04:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 15:04:59 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
ERROR - 2015-08-24 15:04:59 --> Notice - Undefined variable: c_email_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\auth\invite.php on line 6
INFO - 2015-08-24 15:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:05:22 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 15:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:05:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:05:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:05:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:05:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:05:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 15:05:27 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-08-24 15:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:06:20 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 15:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-24 15:06:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:06:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:06:24 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 15:06:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:06:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:06:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:06:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:06:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 15:06:28 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-08-24 15:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:07:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:07:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:07:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 15:07:08 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Clinic_Auth::action_send_invitation
INFO - 2015-08-24 15:07:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:07:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:07:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:10:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:10:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:10:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 15:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:14:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:14:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:14:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 15:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 15:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 15:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 15:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:51:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/completion"
INFO - 2015-08-24 16:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:51:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:51:42 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 16:51:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:51:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 16:51:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:51:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-24 16:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/completion"
INFO - 2015-08-24 16:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:51:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 16:51:53 --> Error - The requested view could not be found: contact/completion.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-24 16:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/completion"
INFO - 2015-08-24 16:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:59:37 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 16:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 16:59:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-24 16:59:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 16:59:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:00:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-24 17:00:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:00:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:00:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/completion"
INFO - 2015-08-24 17:00:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:00:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:00:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:00:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:00:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:09:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:09:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:09:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:10:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:10:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:10:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 17:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:10:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:10:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 17:10:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:10:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:10:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:10:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:10:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:11:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:11:05 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:11:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:11:08 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:11:11 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:11:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:11:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:11:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:11:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:13:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:13:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:13:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:13:55 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:13:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-24 17:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:13:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:13:57 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:13:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:14:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:14:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:14:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:14:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:14:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:14:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:14:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:14:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 17:15:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-24 17:15:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:15:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 17:15:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:22:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 17:22:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:22:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:24:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/send_invitation"
INFO - 2015-08-24 17:24:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:24:18 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-24 17:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-24 17:24:20 --> Parsing Error - syntax error, unexpected ''terms'' (T_CONSTANT_ENCAPSED_STRING) in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\footer.php on line 11
INFO - 2015-08-24 17:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 17:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:24:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:24:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:37:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:37:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:37:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:37:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:37:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:37:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:40:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:40:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:40:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:45:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:45:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:45:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:45:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:45:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:49:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:49:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:49:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:56:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:56:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:56:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 17:57:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 17:57:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 17:57:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:02:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 18:02:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:02:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:02:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:02:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:02:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:02:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:05:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:05:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:05:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:07:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:07:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:07:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:10:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:10:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:10:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:16:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:16:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:16:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:22:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:22:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:22:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:23:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:23:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:23:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:28:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 18:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:28:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:28:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:28:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:30:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:30:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:30:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:33:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:33:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:33:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 18:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:36:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:36:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:36:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-24 18:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-24 18:45:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:45:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-24 18:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:45:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:45:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:58:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:58:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:58:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:58:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:58:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 18:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 18:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 18:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 19:03:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 19:03:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 19:03:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-24 19:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-24 19:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-24 19:04:05 --> Fuel\Core\Request::execute - Setting main Request
