<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-22 10:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 10:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 10:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:10:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:10:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:10:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:15:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:15:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:15:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:16:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:16:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:16:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:34:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:34:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:34:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:34:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:34:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:34:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:34:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:34:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:34:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:34:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:37:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:37:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:37:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-22 11:37:53 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\core\classes\form\instance.php on line 130
INFO - 2015-08-22 11:38:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:38:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:38:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:41:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:41:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:41:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:42:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:42:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:42:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:43:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:43:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:43:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:43:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:43:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:43:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:46:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:46:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:46:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:47:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:47:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:47:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-22 11:47:35 --> Parsing Error - syntax error, unexpected '=>' (T_DOUBLE_ARROW) in C:\Users\yuduru\work\fuelphp\fuel\app\views\index.php on line 99
INFO - 2015-08-22 11:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-22 11:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-22 11:52:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-22 11:52:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-22 11:52:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-22 11:52:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 11:52:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:52:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:52:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:52:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:53:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:53:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:53:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-22 11:53:03 --> Parsing Error - syntax error, unexpected ''class'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' in C:\Users\yuduru\work\fuelphp\fuel\app\views\index.php on line 99
INFO - 2015-08-22 11:53:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:53:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:53:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:58:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:58:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 11:59:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 11:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 11:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:02:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:02:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:02:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:04:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:04:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:04:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:05:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:05:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:05:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:05:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:05:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:05:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:05:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:05:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:05:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:06:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:06:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:06:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:06:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:06:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:06:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:07:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:07:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:07:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:08:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:08:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:08:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:08:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:08:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:09:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:09:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:09:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:12:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:12:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:12:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:12:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:12:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:12:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:13:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:13:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:13:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:14:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:14:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:14:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:15:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:15:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:15:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:17:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:17:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:17:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:18:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:18:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:18:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:19:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:19:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:19:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:20:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:20:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:20:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:20:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:20:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:20:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:20:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:21:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:21:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:21:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:23:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:23:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:23:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:23:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:24:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:24:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:24:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:25:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:25:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:25:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:26:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:26:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:26:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:26:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:26:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:26:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:26:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:28:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-22 12:28:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:28:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:30:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:30:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:30:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:30:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:30:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:30:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:32:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:32:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:32:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-22 12:34:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-22 12:34:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-22 12:34:28 --> Fuel\Core\Request::execute - Setting main Request
