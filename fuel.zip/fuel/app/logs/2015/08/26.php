<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-26 12:18:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:18:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:18:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:21:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 12:21:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:21:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 12:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 12:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 12:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:21:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:22:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 12:22:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:22:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:32:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:32:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:32:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:32:30 --> Fatal Error - Call to a member function check() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 25
INFO - 2015-08-26 12:37:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:37:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:37:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:37:02 --> Fatal Error - Call to a member function check() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 25
INFO - 2015-08-26 12:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:37:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:37:12 --> Fatal Error - Call to a member function check() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 25
INFO - 2015-08-26 12:37:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:37:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:37:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:37:22 --> Fatal Error - Call to a member function check() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 25
INFO - 2015-08-26 12:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:37:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:37:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:37:30 --> Fatal Error - Call to a member function check() on boolean in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 25
INFO - 2015-08-26 12:38:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:38:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:38:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:43:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 12:43:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:43:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:43:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:43:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:43:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:43:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:43:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:43:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:43:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:43:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:44:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:44:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:44:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:48:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
ERROR - 2015-08-26 12:48:13 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/student/logout.php" does not contain class "Controller_Student_Logout" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-08-26 12:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:48:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-26 12:48:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:48:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:50:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:53:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 12:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-26 12:53:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-08-26 12:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:53:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-26 12:53:52 --> Error - View variable is not set: submenu in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-08-26 12:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
ERROR - 2015-08-26 12:58:08 --> Error - File "C:/Users/yuduru/work/fuelphp/fuel/app/classes/controller/template/everyusertemplate.php" does not contain class "Controller_Template_EveryUserTemplate" in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 395
INFO - 2015-08-26 12:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 12:58:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 12:58:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-26 12:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:58:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 12:58:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:58:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 12:58:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:58:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 12:58:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:58:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-26 12:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 12:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 12:59:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-26 13:20:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 13:20:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:20:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:20:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-26 13:20:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-26 13:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 13:20:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-26 13:20:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-08-26 13:20:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:20:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:20:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:20:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:22:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:22:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:22:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:22:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:22:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:22:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:23:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:23:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:23:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:23:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:23:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:23:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:23:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:23:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:23:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 13:24:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:24:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:24:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:24:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 13:24:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:24:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:25:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:25:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:25:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:25:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:25:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:25:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:25:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:25:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:25:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:25:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:25:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:25:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:31:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:31:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:31:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:32:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 13:32:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:32:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:32:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:32:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:32:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:32:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 13:32:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:32:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 13:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:33:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:33:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:33:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:33:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:33:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:33:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-26 13:35:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-26 13:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-26 13:35:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:35:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:35:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:35:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:35:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:35:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 13:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:55:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:55:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:55:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:55:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 13:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:55:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 13:55:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:55:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 13:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:57:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 13:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:57:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 13:57:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:57:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 13:57:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 13:57:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 13:57:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:03:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:03:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:03:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:04:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:06:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:06:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:06:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:07:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:07:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:07:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:07:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:07:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:07:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:08:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:08:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:08:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:08:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:08:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:08:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:08:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-26 14:08:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:08:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:09:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 14:09:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:09:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:10:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:10:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:10:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:10:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:11:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:11:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:11:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 14:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:11:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:16:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 14:16:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:16:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-26 14:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:16:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-26 14:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 14:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 14:17:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:17:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 14:17:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-26 14:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 14:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:17:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-26 14:17:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-26 14:17:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-26 14:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:23:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:23:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:23:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:25:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:25:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:25:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:26:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:26:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:26:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:26:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 14:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:33:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:33:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:33:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:33:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:33:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 14:33:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:33:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:35:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:35:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:35:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:36:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:36:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 14:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-08-26 14:36:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:36:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-08-26 14:36:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:36:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-26 14:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:36:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:38:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:38:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:38:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:40:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:40:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:40:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:40:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:40:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:40:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 14:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-26 14:41:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 14:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:41:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:41:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:41:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:41:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:42:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:42:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:42:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:42:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:42:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:42:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 14:43:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:43:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 14:48:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 14:48:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-26 14:48:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:48:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:49:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-26 14:49:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:49:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:49:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-26 14:49:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:49:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-26 14:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-26 14:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 14:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 14:53:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 14:53:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 14:53:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:03:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 15:03:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:03:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-26 15:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-26 15:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:03:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-26 15:03:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:03:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:03:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:03:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:03:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:05:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/logout"
INFO - 2015-08-26 15:05:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:05:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:05:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:05:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:05:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:06:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-26 15:06:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:06:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/logout"
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:06:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:26:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:26:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:26:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-26 15:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:32:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 15:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 15:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 15:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-26 16:59:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-26 16:59:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-26 16:59:32 --> Fuel\Core\Request::execute - Setting main Request
