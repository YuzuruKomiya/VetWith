<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-08 13:02:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 13:02:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:02:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:02:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:02:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-08 13:02:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:02:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 13:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 13:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:03:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:03:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 13:03:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:03:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-08 13:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-08 13:04:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:04:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:04:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-08 13:04:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:04:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:04:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 13:04:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:04:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 13:16:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:16:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 13:26:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 13:26:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:26:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 13:26:19 --> Error - Could not find asset: 1 in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-08-08 13:26:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 13:26:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 13:26:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 14:34:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-08 14:34:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 14:34:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 14:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-08 14:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 14:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-08 17:51:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-08-08 17:51:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 17:51:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 17:51:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-08 17:51:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:51:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:51:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:51:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:51:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 17:51:20 --> Fatal Error - Class 'Imput' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 777
INFO - 2015-08-08 17:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:53:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 17:53:27 --> Fatal Error - Class 'Imput' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 777
INFO - 2015-08-08 17:53:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:53:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:53:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:53:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 17:53:51 --> Fatal Error - Class 'Imput' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 777
INFO - 2015-08-08 17:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:55:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 17:55:05 --> Notice - Undefined variable: imane_name in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 783
INFO - 2015-08-08 17:55:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:55:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:55:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 17:55:16 --> Error - The requested view could not be found: clinic/mypage/delete_image.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-08 17:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:55:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:55:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:55:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:55:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:55:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:55:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:57:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 17:57:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:57:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 17:59:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 17:59:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 17:59:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:02:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:02:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:02:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-08 18:02:05 --> Notice - Undefined variable: image_name in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 220
INFO - 2015-08-08 18:03:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:03:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:03:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:03:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:03:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:07:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:07:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:07:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:08:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 18:08:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:08:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 18:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:08:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images/c_image"
INFO - 2015-08-08 18:08:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:08:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:08:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:08:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:09:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:09:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:09:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 18:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 18:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:10:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:10:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:10:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:10:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:10:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:12:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:12:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:12:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:13:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:13:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:13:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:16:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:16:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:16:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 18:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:35:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:35:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:35:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:39:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:39:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:39:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 18:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:40:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-08 18:40:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:40:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 18:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 18:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 18:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:35:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 20:35:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:35:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 20:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 20:36:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 20:36:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 20:36:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 20:36:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 20:36:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 20:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:36:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 20:36:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:36:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:40:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:40:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:40:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:41:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:41:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:41:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:52:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:52:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:52:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:52:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-08 20:52:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:52:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:53:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 20:53:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:53:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:54:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 20:54:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:54:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 20:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:55:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 20:55:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:55:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 20:55:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 20:55:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 20:55:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 21:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 21:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 21:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 21:52:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 21:52:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 21:52:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 21:52:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 21:52:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 21:52:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 21:55:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 21:55:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 21:55:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:13:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:13:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:13:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:14:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:14:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:14:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:17:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:17:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:17:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:18:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:18:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:18:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:18:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:19:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:19:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:19:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-08 22:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:19:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-08 22:19:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:19:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-08 22:21:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:21:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:21:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:21:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:23:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:23:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:23:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-08 22:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:23:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:23:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:23:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:24:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:24:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:24:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:28:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:28:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:28:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:28:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-08 22:28:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:28:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:29:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:29:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:29:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:30:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:30:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:30:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:30:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:30:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:30:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:35:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:35:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:35:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:36:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:36:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:36:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:37:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:37:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:37:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:37:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:37:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:37:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:39:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:39:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:39:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:42:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:42:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:42:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:45:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:45:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:45:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:45:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:45:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:47:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:47:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:47:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:47:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:47:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:47:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:47:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:47:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:47:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:48:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:48:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:48:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:49:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:49:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:49:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:49:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:49:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:49:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:49:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-08 22:49:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:49:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:50:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:50:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:50:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:50:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:50:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:50:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:50:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:50:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:50:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 22:52:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 22:52:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 22:52:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:03:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:03:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:03:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:03:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:03:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:06:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:06:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:06:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:06:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:06:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:06:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:07:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:07:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:07:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:19:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:20:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-08 23:20:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:20:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:20:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-08 23:20:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:20:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:31:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-08 23:31:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:31:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:31:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-08 23:31:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:31:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-08 23:55:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-08-08 23:55:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-08 23:55:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-08 23:55:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:55:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-08 23:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-08 23:55:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:55:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-08 23:56:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:56:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 23:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-08 23:56:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:56:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:56:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:56:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:57:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:57:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:57:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:58:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:58:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:58:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:58:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-08 23:58:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:58:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:58:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-08 23:58:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:58:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-08 23:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:58:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-08 23:58:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:58:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-08 23:59:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-08 23:59:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-08 23:59:05 --> Fuel\Core\Request::execute - Setting main Request
