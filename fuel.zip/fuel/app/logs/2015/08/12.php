<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-12 12:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
age/bookmark"
INFO - 2015-08-12 12:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:58:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 12:58:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:58:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 12:58:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:58:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 12:59:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 12:59:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 12:59:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:40:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 13:40:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:40:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-12 13:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 13:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:40:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 13:40:34 --> Fatal Error - Call to undefined method Fuel\Core\Database_MySQLi_Result::as_arary() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 85
INFO - 2015-08-12 13:46:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 13:46:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:46:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:48:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 13:48:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:48:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:49:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 13:49:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:49:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:49:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 13:49:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:49:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:49:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 13:49:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:49:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 13:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:49:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 13:49:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 13:49:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 13:49:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:03:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:04:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:04:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:04:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:05:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:05:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:05:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:06:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:06:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:06:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:06:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-12 14:06:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:06:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:09:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:09:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 14:09:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:09:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 14:09:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 14:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 14:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 15:55:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:55:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:55:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 15:55:01 --> Warning - Missing argument 1 for Model_Offers::get_offer_array_by_offer_id_array(), called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 31 and defined in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 134
INFO - 2015-08-12 15:56:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:56:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:56:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 15:56:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-12 15:56:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:56:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 15:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 15:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 15:58:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:58:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:58:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 15:58:05 --> Warning - mysqli_result::data_seek() expects parameter 1 to be long, string given in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\result.php on line 36
INFO - 2015-08-12 15:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:59:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 15:59:13 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-12 15:59:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:59:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:59:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 15:59:18 --> Warning - mysqli_result::data_seek() expects parameter 1 to be long, string given in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\result.php on line 36
INFO - 2015-08-12 15:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 15:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 15:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:00:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:00:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:00:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:00:52 --> Notice - Undefined index: c_username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 86
INFO - 2015-08-12 16:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:00:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:00:58 --> Notice - Undefined index: username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 86
INFO - 2015-08-12 16:01:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:01:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:01:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:01:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:01:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:01:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 16:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:02:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 16:02:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:02:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:02:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 16:02:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:02:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:02:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:02:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:02:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:07:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:07:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:07:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:08:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:08:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:08:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:11:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:11:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:11:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:11:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:11:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:11:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:12:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:12:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:12:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:14:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:14:11 --> Notice - Undefined variable: c_username_array in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 87
INFO - 2015-08-12 16:14:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:14:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:14:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:15:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:15:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:15:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:16:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:16:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 16:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:16:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 16:16:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 16:16:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:16:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:16:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:16:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:18:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:18:47 --> Warning - mysqli_result::data_seek() expects parameter 1 to be long, string given in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\result.php on line 36
INFO - 2015-08-12 16:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:22:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:22:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:22:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:23:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:23:48 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 95
INFO - 2015-08-12 16:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:27:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:27:27 --> Fatal Error - Call to a member function current() on array in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 95
INFO - 2015-08-12 16:27:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:27:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:27:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:28:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:28:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:28:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:31:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:31:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:31:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 16:31:48 --> Parsing Error - syntax error, unexpected '}' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\offers.php on line 97
INFO - 2015-08-12 16:31:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:31:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:31:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:32:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:32:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:32:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:33:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:33:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:33:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 16:36:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 16:36:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 16:36:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:00:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:00:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:00:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:08:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:08:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:08:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:10:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:10:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:10:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:10:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 17:10:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:10:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 17:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:10:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:10:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:10:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-12 17:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-12 17:13:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:19:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:19:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:19:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 17:19:15 --> Fatal Error - Call to undefined method Model_Offers::get_profile_array_by_c_username_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 32
INFO - 2015-08-12 17:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:19:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 17:19:30 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 15
INFO - 2015-08-12 17:20:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:20:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:20:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 17:20:00 --> Warning - Illegal string offset 'c_name' in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 15
INFO - 2015-08-12 17:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:20:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:20:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:20:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 17:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 17:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:21:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:21:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:21:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:24:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:24:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:24:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 17:24:16 --> Notice - Undefined variable: profile_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 12
INFO - 2015-08-12 17:24:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:24:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:24:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:24:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:24:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:24:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:24:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:24:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:24:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:25:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:28:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:28:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:28:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:36:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:36:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:36:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:37:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:37:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 17:37:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:37:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:37:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:37:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:37:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:38:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:38:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:38:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:38:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:38:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:38:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:48:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 17:48:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:48:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-12 17:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-12 17:50:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-12 17:50:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 17:50:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:50:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:50:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:52:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:52:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:52:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:52:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:52:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:52:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:53:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-12 17:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-12 17:53:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-12 17:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-12 17:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-12 17:53:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:53:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-12 17:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:54:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:54:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:54:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:54:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:54:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:54:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:54:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 17:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:55:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 17:55:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:55:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:55:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:55:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:55:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 17:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 17:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 17:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:02:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:02:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:02:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:02:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:02:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:02:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:02:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:02:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:02:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:03:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:03:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:03:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:03:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:03:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:03:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:06:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:06:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:06:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:10:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:10:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:10:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:11:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:11:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:11:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:14:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 18:14:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:14:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:14:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 18:14:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:14:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:14:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 18:14:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:14:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:16:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:16:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:16:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 18:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:16:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-08-12 18:16:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:16:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 18:16:48 --> Notice - Undefined property: Auth\Auth_Login_Studentauth::$logout in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\template\clinicauthtemplate.php on line 14
INFO - 2015-08-12 18:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/logout"
INFO - 2015-08-12 18:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-12 18:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-12 18:17:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 18:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 18:17:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:17:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:17:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:17:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:17:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:17:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:17:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:17:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:18:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 18:18:47 --> Notice - Undefined variable: auth in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\template\clinicexclusivetemplate.php on line 22
INFO - 2015-08-12 18:19:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:19:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:19:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:27:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:30:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-12 18:30:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:30:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:30:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:38:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:38:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:38:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:41:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 18:41:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:41:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:46:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:46:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:46:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-12 18:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-12 18:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 18:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-12 18:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 18:48:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 18:48:55 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-12 21:58:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 21:58:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 21:58:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 21:58:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 21:58:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 21:58:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 22:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:00:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 22:01:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 22:01:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:01:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 22:01:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:01:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 22:02:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 22:02:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 22:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:02:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:33:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 22:33:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:33:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:33:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:33:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:33:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:33:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:33:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:34:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:34:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-12 22:34:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 22:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 22:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 22:34:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 22:34:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 22:34:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:08:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-12 23:08:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:08:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:08:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:08:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:08:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:08:41 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 3
INFO - 2015-08-12 23:08:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:08:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:08:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:08:56 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 3
INFO - 2015-08-12 23:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:09:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:10:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:10:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:10:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:11:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:11:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:11:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:11:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:11:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:11:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:13:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:13:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:13:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:15:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:15:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:15:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:18:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:18:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:18:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:18:06 --> Warning - unserialize() expects parameter 1 to be string, array given in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 83
INFO - 2015-08-12 23:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:18:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:18:28 --> Warning - unserialize() expects parameter 1 to be string, array given in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\bookmark.php on line 82
INFO - 2015-08-12 23:18:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:18:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:18:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:23:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:23:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:23:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:24:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:24:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:24:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:30:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:30:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:30:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:30:29 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 3
INFO - 2015-08-12 23:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:30:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:30:38 --> Notice - Undefined variable: bookmarks_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 3
INFO - 2015-08-12 23:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:31:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-12 23:31:15 --> Notice - Undefined index: id in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 20
INFO - 2015-08-12 23:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 23:32:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:32:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 23:32:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:33:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:33:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:33:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:34:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 23:34:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:34:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-12 23:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:34:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 23:34:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:34:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-12 23:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:35:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-12 23:35:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 23:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-12 23:35:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-12 23:35:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:35:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:35:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:35:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-12 23:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-12 23:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-12 23:39:40 --> Fuel\Core\Request::execute - Setting main Request
