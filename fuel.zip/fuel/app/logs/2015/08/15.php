<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-15 15:32:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 15:32:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:32:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:32:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 15:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:32:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 15:32:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:32:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:33:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 15:33:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:33:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:33:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 15:33:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:33:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:33:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 15:33:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:33:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 15:33:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 15:33:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 15:33:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 16:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 16:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 16:13:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 16:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "apply/5"
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 16:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 16:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 16:13:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:13:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-15 16:13:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:13:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:14:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-15 16:14:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:14:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:14:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-15 16:14:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:14:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:14:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 16:14:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:14:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:14:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 16:14:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:14:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 16:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 16:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-15 16:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:32:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 16:32:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:32:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:44:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:44:35 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:44:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:44:54 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:44:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:44:57 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:45:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:45:04 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:45:08 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:45:11 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:45:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:45:18 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:57:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:57:07 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
ERROR - 2015-08-15 16:57:11 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:57:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:57:35 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:58:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:58:02 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:58:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 16:58:21 --> Compile Error - Can't use function return value in write context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 16:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 16:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 16:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 16:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 16:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:00:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 17:00:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:00:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:00:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:00:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:00:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:00:07 --> Notice - Undefined index: apply in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 34
INFO - 2015-08-15 17:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:00:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:00:47 --> Notice - Undefined index: apply in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:00:50 --> Notice - Undefined index: apply in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:00:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:00:50 --> Notice - Undefined index: apply in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 36
INFO - 2015-08-15 17:01:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:01:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:01:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:01:04 --> Notice - Undefined index: apply in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 35
INFO - 2015-08-15 17:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
ERROR - 2015-08-15 17:33:30 --> Parsing Error - syntax error, unexpected '$this' (T_VARIABLE) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\mypage.php on line 41
INFO - 2015-08-15 17:33:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:33:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:33:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-15 17:33:49 --> Notice - Undefined index: c_id in C:\Users\yuduru\work\fuelphp\fuel\app\views\student\mypage\bookmark.php on line 20
INFO - 2015-08-15 17:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:37:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:37:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:37:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:42:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:42:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:42:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:43:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:43:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:43:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:44:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:44:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:55:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:55:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:55:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:57:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:57:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:57:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 17:59:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 17:59:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 17:59:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:00:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:00:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:00:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:05:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:05:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:05:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:06:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:06:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:06:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:19:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:19:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:19:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:20:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:20:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:20:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:21:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 18:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 18:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 18:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-15 22:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-15 22:21:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:21:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-15 22:21:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-15 22:21:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-15 22:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:21:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:21:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:21:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:26:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-15 22:26:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:26:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-15 22:26:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-15 22:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-15 22:26:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-15 22:26:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:26:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:26:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-15 22:26:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:26:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:27:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:27:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:27:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:27:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:27:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 22:27:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:27:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:27:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:27:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:27:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:28:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:34:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 22:34:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:34:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:34:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:34:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:34:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-15 22:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:34:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:34:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:34:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:34:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:37:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:37:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:37:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:37:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:37:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:37:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:37:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:37:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:37:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:37:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 22:37:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:37:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:38:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:38:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 22:38:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:38:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-15 22:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:39:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:39:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:39:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 22:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:48:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-15 22:48:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:48:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:48:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 22:48:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:48:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:48:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:48:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:48:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:48:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 22:49:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:49:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 22:50:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-15 22:50:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-15 22:50:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:50:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 22:50:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:50:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:58:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 22:58:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:58:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 22:59:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 22:59:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 22:59:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:00:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:00:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:00:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:00:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:00:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:00:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:11:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:11:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:11:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:11:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:11:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:11:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:30:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:30:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:30:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:30:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:30:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:30:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:31:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:31:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:31:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:31:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:31:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:31:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:32:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:32:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:32:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:33:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:33:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:33:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:34:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:34:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:34:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:36:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:36:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:36:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:36:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:36:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:36:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:41:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:41:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:41:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:41:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:41:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:41:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:41:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:41:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:41:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:42:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:42:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:42:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:42:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:42:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:42:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:42:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:42:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:43:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:43:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:43:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:44:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:44:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:44:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:45:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:45:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:45:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:45:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:45:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:46:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:46:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:46:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:46:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:46:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:46:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:47:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:47:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:47:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:48:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:49:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:49:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:49:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:49:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:49:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:49:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:49:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:49:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:49:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:50:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:50:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:50:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:51:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:51:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:51:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:55:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:55:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:55:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:55:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 23:56:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 23:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 23:56:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-15 23:56:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-15 23:56:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 23:56:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 23:56:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-15 23:56:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 23:56:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 23:56:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-15 23:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 23:56:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:56:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 23:56:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:56:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 23:57:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 23:57:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-15 23:57:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-15 23:57:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-15 23:57:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-15 23:57:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-15 23:57:19 --> Fuel\Core\Request::execute - Setting main Request
