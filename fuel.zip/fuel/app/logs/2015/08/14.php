<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-14 00:04:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:04:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:04:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:04:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:04:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:04:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:05:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:05:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:05:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:05:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:05:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:05:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:05:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:07:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 00:07:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:07:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-14 00:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-14 00:08:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-14 00:08:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-14 00:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-14 00:08:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-14 00:08:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 00:08:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-14 00:08:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 00:08:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-14 15:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:24:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 15:24:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:24:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:24:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 15:24:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:24:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:24:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-14 15:24:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:24:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:43:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 15:43:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:43:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:43:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 15:43:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:43:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 15:43:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 15:43:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 15:43:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:38:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 16:38:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:38:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:38:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:38:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:38:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 16:38:32 --> Notice - Undefined variable: form in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 184
INFO - 2015-08-14 16:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:39:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 16:39:19 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-14 16:39:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:39:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:39:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:40:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:40:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:40:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:41:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:41:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:41:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:42:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:42:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:42:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:46:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:46:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:46:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-14 16:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:55:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:55:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:55:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 16:58:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 16:58:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 16:58:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 16:58:17 --> Notice - Undefined variable: c_profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\apply.php on line 3
INFO - 2015-08-14 17:00:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:00:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:00:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:01:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:01:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:01:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:01:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:01:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:01:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:04:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:04:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:04:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:04:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 17:04:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:04:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:04:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 17:04:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:04:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:07:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:14:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:14:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:14:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:14:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:15:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:15:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:15:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:15:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:15:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:15:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:17:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:17:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:17:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:25:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:25:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:25:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:44:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:44:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:44:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm"
INFO - 2015-08-14 17:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 17:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:45:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:45:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:45:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm5"
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:45:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:45:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:45:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:45:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:46:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:46:01 --> Fatal Error - Class 'Imput' not found in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 205
INFO - 2015-08-14 17:46:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 17:46:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:46:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:46:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:46:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:46:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:46:18 --> Fatal Error - Undefined class constant 'method' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 205
INFO - 2015-08-14 17:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:46:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:46:38 --> Error - The requested view could not be found: clinic/mypage/apply_confirm/5.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-14 17:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:46:54 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:46:54 --> Error - The requested view could not be found: clinic/mypage/apply_confirm/.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-14 17:47:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:47:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:47:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:47:04 --> Error - The requested view could not be found: clinic/mypage/apply_confirm.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-14 17:47:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:47:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:47:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:47:24 --> Error - The requested view could not be found: clinic/mypage/apply_confirm.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-14 17:47:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:47:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:47:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:47:46 --> Error - The requested view could not be found: offers/apply_confirm/.php in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 398
INFO - 2015-08-14 17:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:48:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:48:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:48:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:49:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:49:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:49:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:49:29 --> Notice - Undefined index: c_id in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\apply_confirm.php on line 7
INFO - 2015-08-14 17:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:49:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 17:49:50 --> Notice - Undefined index: c_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\apply_confirm.php on line 7
INFO - 2015-08-14 17:49:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:49:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:49:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 17:50:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 17:50:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 17:50:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:42:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:42:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:42:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-14 18:42:13 --> Notice - Undefined index: catchcopy in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\apply_confirm.php on line 26
INFO - 2015-08-14 18:43:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:43:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:43:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:43:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:43:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:43:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:44:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:44:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-14 18:44:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-14 18:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-14 18:44:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-14 18:44:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-14 18:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-14 18:44:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 18:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:44:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 18:45:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 18:45:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 18:45:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 18:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 18:46:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 18:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 18:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 18:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 18:46:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:46:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:47:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/offer/5"
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/offer/5"
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/offer/5"
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:47:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/offer/apply/5"
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:47:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offer/apply/5"
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:47:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:48:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 18:48:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:48:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:48:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 18:48:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:48:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:51:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 18:51:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:51:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:51:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 18:51:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:51:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 18:51:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 19:16:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 19:16:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 19:16:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 19:17:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-14 19:17:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 19:17:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 19:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-14 19:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 19:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 19:17:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-14 19:17:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 19:17:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 19:17:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-14 19:17:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 19:17:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 22:20:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-14 22:20:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 22:20:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 22:20:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-14 22:20:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 22:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-14 22:21:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 22:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:21:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:23:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:23:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:23:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-14 22:24:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:24:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-14 22:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/5"
INFO - 2015-08-14 22:24:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:24:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/5"
INFO - 2015-08-14 22:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:24:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:24:55 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-14 22:24:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:31:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-14 22:31:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:31:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-14 22:31:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-14 22:31:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-14 22:31:23 --> Fuel\Core\Request::execute - Setting main Request
