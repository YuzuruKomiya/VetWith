<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:00:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-16 00:00:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-16 00:00:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:00:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-16 00:00:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:00:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 00:00:47 --> メールアドレス重複エラー: そのメールアドレスは既に登録されています。Controller_Student_Auth::action_send_invitation
INFO - 2015-08-16 00:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 00:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:01:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 00:01:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:01:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 00:01:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:01:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 00:01:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:01:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 00:01:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 00:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:02:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:02:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:02:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:02:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:02:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:02:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:04:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-16 00:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:10:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:10:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:10:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:16:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-16 00:16:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:16:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:16:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:16:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:16:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-16 00:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 00:17:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-16 00:17:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 00:17:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 18:29:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 18:29:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 18:29:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 18:29:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:29:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:29:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:29:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:29:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:40:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:40:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:40:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:42:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:42:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:42:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 18:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 18:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 18:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:39:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
ERROR - 2015-08-16 21:39:27 --> Runtime Notice - call_user_func() expects parameter 1 to be a valid callback, non-static method Controller_Clinic_Mypage::_init() should not be called statically in C:\Users\yuduru\work\fuelphp\fuel\core\classes\autoloader.php on line 375
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:40:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:40:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-16 21:40:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:40:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:40:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:40:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:40:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:41:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:41:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:41:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 21:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:41:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:41:57 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 21:41:57 --> Notice - Undefined variable: data in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 25
INFO - 2015-08-16 21:42:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:42:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:42:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 21:42:08 --> Notice - Undefined variable: new_apply_count in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 25
INFO - 2015-08-16 21:42:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:42:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:42:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 21:42:12 --> Notice - Undefined variable: new_apply_count in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 25
INFO - 2015-08-16 21:52:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
ERROR - 2015-08-16 21:52:27 --> Fatal Error - Using $this when not in object context in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 8
INFO - 2015-08-16 21:54:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 21:54:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 21:54:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:07:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:07:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:07:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:12:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:12:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:12:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:12:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:12:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:13:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:13:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:13:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:13:29 --> Notice - Undefined variable: data in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 26
INFO - 2015-08-16 22:13:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:13:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:13:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:13:44 --> Notice - Undefined variable: new_apply_count in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\submenu.php on line 26
INFO - 2015-08-16 22:16:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:16:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:16:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:16:33 --> Error - View variable is not set: submenu in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-08-16 22:16:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:16:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:16:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:16:59 --> Error - View variable is not set: submenu in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-08-16 22:17:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:17:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:17:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:17:10 --> Error - View variable is not set: content in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-08-16 22:17:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:17:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:17:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:17:29 --> Error - View variable is not set: content in C:\Users\yuduru\work\fuelphp\fuel\core\classes\view.php on line 450
INFO - 2015-08-16 22:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:18:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-16 22:18:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 22:18:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:18:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:18:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:18:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:18:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:18:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:18:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:19:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:19:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:19:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:19:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:19:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:19:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-16 22:26:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-16 22:26:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 22:26:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:28:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:28:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:28:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:28:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-16 22:36:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 22:36:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 22:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:36:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:36:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:43:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:43:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:43:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:43:36 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::as_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 270
INFO - 2015-08-16 22:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:49:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 22:49:37 --> Fatal Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::as_array() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 270
INFO - 2015-08-16 22:49:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:49:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:49:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:55:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:55:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:55:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:57:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:57:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:57:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 22:59:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 22:59:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 22:59:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:03:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-16 23:03:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:03:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 23:03:00 --> Notice - Undefined variable: c_id in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 18
INFO - 2015-08-16 23:03:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 23:03:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:03:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:03:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-16 23:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:03:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-16 23:03:32 --> Notice - Undefined variable: c_id in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 18
INFO - 2015-08-16 23:03:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-16 23:03:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:03:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-16 23:17:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 23:17:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:17:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 23:17:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-16 23:17:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-16 23:17:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:17:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-08-16 23:17:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:17:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-08-16 23:17:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-08-16 23:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:18:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-16 23:18:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:18:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-16 23:18:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-16 23:18:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-16 23:18:02 --> Fuel\Core\Request::execute - Setting main Request
