<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-09 12:47:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-09 12:47:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:47:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:47:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-09 12:47:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:47:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:47:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-09 12:47:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:47:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 12:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:48:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-09 12:48:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:48:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-09 12:49:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-09 12:49:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-09 12:49:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-09 12:49:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:49:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-09 12:49:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:49:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:50:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-09 12:50:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:50:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 12:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:50:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 12:50:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:50:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:51:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 12:51:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:51:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:51:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 12:51:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:51:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:51:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-09 12:51:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:51:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-09 12:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/ddc40460d60961dab5d68099fe89b782921f07a6"
INFO - 2015-08-09 12:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:52:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/ddc40460d60961dab5d68099fe89b782921f07a6"
INFO - 2015-08-09 12:52:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:52:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:53:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-09 12:53:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:53:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-09 12:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:53:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/ddc40460d60961dab5d68099fe89b782921f07a6"
INFO - 2015-08-09 12:53:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:53:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:53:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-09 12:53:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:53:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 12:53:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_completion"
INFO - 2015-08-09 12:53:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 12:53:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 14:59:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 14:59:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student"
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-09 14:59:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 14:59:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-09 14:59:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 14:59:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 15:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-09 15:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 15:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 15:43:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-09 15:43:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 15:43:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:45:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:45:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:45:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:45:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:45:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:45:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:45:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:45:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:45:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:46:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:46:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:46:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:46:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:47:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:47:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:47:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:47:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:47:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:47:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:48:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:48:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:48:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:49:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:49:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:49:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:49:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:49:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:49:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:53:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:53:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:53:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:54:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:54:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:54:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:56:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:56:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:56:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 16:58:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 16:58:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 16:58:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:00:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:00:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:00:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:01:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:01:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:01:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:01:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:01:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:01:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:08:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:08:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:08:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:11:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:11:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:11:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:11:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:11:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:11:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:12:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-09 17:12:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:12:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:12:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:12:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:12:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:15:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:15:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:15:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:15:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:15:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:15:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:16:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:16:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:16:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:16:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:16:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:16:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:17:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:17:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:17:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:17:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:17:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:17:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:18:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:18:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:18:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:21:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:21:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:21:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:22:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:22:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:22:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:22:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:22:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:22:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:23:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:23:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:24:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:24:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:24:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:25:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:25:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:25:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:25:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:25:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:25:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:26:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:26:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:26:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:26:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:26:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:26:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:26:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:26:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:26:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-09 17:34:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-09 17:34:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-09 17:34:14 --> Fuel\Core\Request::execute - Setting main Request
