<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-17 12:34:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 12:34:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 12:34:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-17 12:34:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-17 12:34:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-17 12:34:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 12:34:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:34:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-17 12:34:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:34:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:35:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-08-17 12:35:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:35:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 12:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 12:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 12:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-17 13:01:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:01:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-17 13:01:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:01:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-17 13:01:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:01:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:01:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:01:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:08:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:08:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:08:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:08:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:08:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:08:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:08:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 13:08:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:08:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:58:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 13:58:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:58:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 13:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 13:59:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 13:59:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 13:59:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 14:00:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:00:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:00:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-17 14:00:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:00:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:00:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-17 14:00:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:00:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:00:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 14:00:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:00:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:01:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 14:01:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:01:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:01:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:01:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:01:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-17 14:05:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 14:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-17 14:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 14:05:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 14:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:05:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:05:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:05:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:05:28 --> Fatal Error - Call to a member function get_timestamp() on string in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 401
INFO - 2015-08-17 14:06:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 14:06:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:06:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:06:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:06:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:06:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:06:34 --> Fatal Error - Call to a member function format() on integer in C:\Users\yuduru\work\fuelphp\fuel\packages\auth\classes\auth\login\clinicauth.php on line 401
INFO - 2015-08-17 14:10:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 14:10:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:10:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:10:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:10:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:10:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:11:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-17 14:11:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:11:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:11:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/confirm_detail"
INFO - 2015-08-17 14:11:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:11:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:11:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:11:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:11:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:26:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:26:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:26:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:26:26 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 16
INFO - 2015-08-17 14:42:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail_completion"
INFO - 2015-08-17 14:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:42:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:42:40 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-17 14:42:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:42:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:42:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:42:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:42:46 --> Notice - Undefined variable: bookmark in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 20
INFO - 2015-08-17 14:44:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:44:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:44:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:44:18 --> Notice - Undefined variable: username in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 260
INFO - 2015-08-17 14:44:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:44:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:44:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:45:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:45:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:45:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:47:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:47:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:47:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:48:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:48:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:48:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:49:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:49:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:49:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:52:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:52:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:52:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:52:12 --> Notice - Undefined index: students.email in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 281
INFO - 2015-08-17 14:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:52:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:52:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:52:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:53:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:53:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:53:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:55:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:55:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:55:02 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:55:02 --> Notice - Undefined index: l_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 20
INFO - 2015-08-17 14:55:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:55:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:55:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:55:14 --> Notice - Undefined index: l_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 20
INFO - 2015-08-17 14:55:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:55:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:55:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:55:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:55:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:55:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:56:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:56:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:56:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:57:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:57:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:57:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:57:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:57:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:57:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:58:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:58:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:58:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:58:16 --> Notice - Undefined index: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 20
INFO - 2015-08-17 14:58:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:58:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 14:58:30 --> Notice - Undefined index: l_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 20
INFO - 2015-08-17 14:58:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:58:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:58:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:59:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:59:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:59:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 14:59:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 14:59:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 14:59:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:00:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:00:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:00:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:02:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:02:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:02:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 15:02:11 --> Parsing Error - syntax error, unexpected 'array_merge' (T_STRING) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 281
INFO - 2015-08-17 15:02:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:02:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:02:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:02:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:02:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:02:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:05:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:05:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:05:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:06:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:06:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:06:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:07:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:07:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:07:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:10:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:10:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:10:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 15:10:17 --> Notice - Undefined variable: profile_array in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 289
INFO - 2015-08-17 15:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:10:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:31:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:31:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:31:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:31:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:31:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:31:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:31:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:31:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:31:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:32:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:32:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:32:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:36:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:36:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:36:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:39:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:39:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:39:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:39:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:39:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:39:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:40:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:40:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:40:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:40:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:40:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:40:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:53:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:53:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:53:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 15:53:51 --> Notice - Undefined index: created_at in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 21
INFO - 2015-08-17 15:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 15:57:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 15:57:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 15:57:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 15:57:51 --> Notice - A non well formed numeric value encountered in C:\Users\yuduru\work\fuelphp\fuel\core\classes\date.php on line 332
INFO - 2015-08-17 16:01:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:01:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:01:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:02:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-17 16:02:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-17 16:02:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/5"
INFO - 2015-08-17 16:02:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_confirm/5"
INFO - 2015-08-17 16:02:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:02:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply_completion/5"
INFO - 2015-08-17 16:02:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:02:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:03:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 16:03:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:03:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:03:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:03:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:03:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:03:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:05:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:05:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:05:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:07:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:07:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:07:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:07:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:07:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:07:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:07:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:07:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:07:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:08:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:08:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:08:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:08:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:08:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:08:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:08:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:08:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:08:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:09:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:09:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:09:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:10:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:10:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:10:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:23:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:23:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:23:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:25:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:25:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:25:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:27:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:27:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:27:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:31:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:31:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:31:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:39:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:39:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:39:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:39:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:39:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:39:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:41:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:41:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:41:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:41:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:41:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:41:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:41:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 16:41:53 --> Parsing Error - syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 28
INFO - 2015-08-17 16:42:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:42:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:42:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:42:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:42:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:42:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:43:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:43:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:43:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:43:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:44:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:44:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:44:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:44:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:44:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:44:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:44:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:44:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:44:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:44:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:44:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:44:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:47:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:47:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:47:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:49:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:49:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:49:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:52:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 16:53:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 16:53:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 16:53:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:24:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 20:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:24:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 20:24:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:24:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:24:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 20:24:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:24:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-17 20:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:34:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 20:34:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:34:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:40:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 20:40:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:40:19 --> Fatal Error - Call to undefined function base() in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_apply.php on line 45
INFO - 2015-08-17 20:40:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 20:40:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "mypage/apply_detail/2"
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:40:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 20:40:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:40:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:40:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:40:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:40:50 --> Notice - Undefined index: already_read in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 918
INFO - 2015-08-17 20:41:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:41:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:41:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:41:20 --> Notice - Undefined index: already_read in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 918
INFO - 2015-08-17 20:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:41:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:41:48 --> Notice - Undefined index: l_name in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 37
INFO - 2015-08-17 20:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:44:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:44:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:44:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 20:46:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:46:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:46:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:46:33 --> Parsing Error - syntax error, unexpected 'return' (T_RETURN) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 337
INFO - 2015-08-17 20:46:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:46:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:46:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:46:40 --> Fatal Error - Function name must be a string in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 332
INFO - 2015-08-17 20:46:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:46:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:46:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:46:56 --> Notice - Undefined index: profile_fields in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 333
INFO - 2015-08-17 20:52:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 20:52:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 20:52:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 20:52:42 --> Warning - Illegal string offset 'id' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 335
INFO - 2015-08-17 21:12:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:12:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:12:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 21:12:48 --> Notice - Undefined property: Fuel\Core\Database_Query_Builder_Select::$execute in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 328
INFO - 2015-08-17 21:13:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:13:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:13:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:16:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:16:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:16:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:18:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:18:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:18:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:19:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:19:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:19:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:19:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:19:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:19:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:19:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:19:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:19:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:19:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:19:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:19:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:20:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:20:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:20:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:20:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 21:20:26 --> Warning - Illegal string offset 'already_read' in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 23
INFO - 2015-08-17 21:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:25:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:25:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:25:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:25:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:25:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:25:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 21:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:26:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:26:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 21:26:50 --> Runtime Recoverable error - Argument 1 passed to Fuel\Core\Database_Query_Builder_Update::set() must be of the type array, string given, called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 357 and defined in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\query\builder\update.php on line 76
INFO - 2015-08-17 21:57:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:57:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:57:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 21:57:04 --> Runtime Recoverable error - Argument 1 passed to Fuel\Core\Database_Query_Builder_Update::set() must be of the type array, string given, called in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 357 and defined in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\query\builder\update.php on line 76
INFO - 2015-08-17 21:59:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 21:59:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 21:59:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:00:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 22:00:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:00:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:24:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:24:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:24:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:28:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 22:28:29 --> Notice - Undefined variable: apply in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 4
INFO - 2015-08-17 22:28:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:28:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:28:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:28:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:28:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:28:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:28:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:28:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:28:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:29:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:29:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:29:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:30:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:30:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:30:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:30:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:30:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:30:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:31:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:31:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:31:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 22:39:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 22:39:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 22:39:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:21:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:21:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:21:44 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 23:21:44 --> Warning - array_merge(): Argument #2 is not an array in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 339
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:23:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:24:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-17 23:24:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:24:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:24:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-17 23:24:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:24:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:25:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/send_invitation"
INFO - 2015-08-17 23:25:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:25:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:25:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/046973487fa1fe4b853df01e5ca75f311bbba028"
INFO - 2015-08-17 23:25:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:25:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:27:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register/046973487fa1fe4b853df01e5ca75f311bbba028"
INFO - 2015-08-17 23:27:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:27:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:27:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-17 23:27:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:27:53 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 23:27:53 --> Fatal Error - Access to undeclared static property: Controller_Student_Auth::$prefecture in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth.php on line 358
INFO - 2015-08-17 23:28:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-17 23:28:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:28:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 23:28:47 --> Fatal Error - Access to undeclared static property: Controller_Clinic_Mypage::$prefecture in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\student\auth.php on line 358
INFO - 2015-08-17 23:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_confirm"
INFO - 2015-08-17 23:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:29:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:29:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/register_completion"
INFO - 2015-08-17 23:29:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:29:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/delete_images"
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-17 23:47:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-17 23:47:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-17 23:47:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:47:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:47:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:47:58 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-17 23:47:58 --> Notice - Undefined variable: zip3 in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 49
INFO - 2015-08-17 23:48:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:48:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:48:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:48:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:48:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:48:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:49:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:49:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:49:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-17 23:51:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-17 23:51:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-17 23:51:04 --> Fuel\Core\Request::execute - Setting main Request
