<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-19 09:20:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 09:20:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:20:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 09:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:20:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:20:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 09:20:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:20:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:21:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 09:21:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:21:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:22:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 09:22:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:22:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:23:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 09:23:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:23:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 09:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:52:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 09:52:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:52:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:54:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 09:54:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:54:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 09:54:04 --> Parsing Error - syntax error, unexpected ''clinic/mypage/report/'' (T_CONSTANT_ENCAPSED_STRING) in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 102
INFO - 2015-08-19 09:54:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 09:54:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:54:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:54:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 09:54:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:54:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:54:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 09:54:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:54:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 09:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:57:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 09:57:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:57:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 09:57:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 09:57:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 09:57:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:00:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:00:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:00:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:31:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:31:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:31:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:31:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:31:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:31:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:32:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:32:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:32:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:32:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:32:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:32:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:32:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:32:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:32:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:32:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:32:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:32:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:33:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:33:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:33:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:35:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:35:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:35:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:35:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:35:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:35:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:35:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:35:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:35:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 10:36:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 10:36:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:36:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:36:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 10:36:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 10:36:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:36:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 10:36:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:36:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:37:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 10:37:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:37:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:38:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:38:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:38:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:39:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:39:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:39:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 10:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 10:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 10:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-19 14:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 14:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:21:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:22:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 14:22:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:22:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:22:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-19 14:22:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:22:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:22:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:22:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-19 14:22:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:22:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:24:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:24:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:24:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:25:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:25:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:25:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:25:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:25:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:25:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:25:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:25:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:25:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:26:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:26:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:26:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:26:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:26:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:26:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:26:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-19 14:26:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:26:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:27:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-19 14:27:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:27:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:27:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-19 14:27:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:27:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:27:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 14:27:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:27:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:27:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 14:27:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:27:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:27:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:27:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:27:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:28:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:28:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:28:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 14:59:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 14:59:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 14:59:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:45:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 15:45:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:45:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:45:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:45:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:45:25 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 15:45:25 --> Fatal Error - Undefined class constant 'method' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 1013
INFO - 2015-08-19 15:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 15:45:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:45:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:46:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:46:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:46:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:47:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:47:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:47:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:47:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:47:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:47:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:47:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:47:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:47:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:47:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:48:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:48:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:48:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:48:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:48:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:48:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:48:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:48:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:48:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 15:48:34 --> 1136 - Column count doesn't match value count at row 1 [ INSERT INTO `reports` (`0`) VALUES ('見学と面談を実施', '内定を出し、雇用できた', 'うんこ！', '2', 'aaaaaaaa', 'aaaaaaaa') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-19 15:54:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:54:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:54:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:54:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:54:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:54:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 15:55:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:55:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:55:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 15:55:46 --> 1136 - Column count doesn't match value count at row 1 [ INSERT INTO `reports` (`0`) VALUES ('実習を実施', '内定を出し、雇用できた', 'うんこ', '2', 'aaaaaaaa', 'aaaaaaaa') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-19 15:58:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 15:58:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 15:58:49 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 15:58:49 --> 1136 - Column count doesn't match value count at row 1 [ INSERT INTO `reports` (`0`) VALUES ('実習を実施', '内定を出し、雇用できた', 'うんこ', '2', 'aaaaaaaa', 'aaaaaaaa') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-19 16:01:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:01:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:01:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:01:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:01:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:01:25 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 16:01:25 --> 1136 - Column count doesn't match value count at row 1 [ INSERT INTO `reports` (`0`) VALUES ('実施せず', 'その他', '', '2', 'aaaaaaaa', 'aaaaaaaa') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-19 16:02:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:02:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:02:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:03:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 16:03:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:03:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:03:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 16:03:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:03:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:04:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 16:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:04:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:04:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:04:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:04:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 16:04:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:04:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 16:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:06:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:06:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:06:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:06:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 16:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:08:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:46 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-19 16:08:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:08:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:08:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:08:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:08:51 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-19 16:08:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:10:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 16:10:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 16:10:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:10:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:10:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:10:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:11:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:11:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:11:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:11:17 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-19 16:11:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:12:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:12:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:12:04 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-19 16:12:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:12:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:12:43 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-19 16:12:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-19 16:12:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report_completion/2"
INFO - 2015-08-19 16:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:13:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:13:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:13:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:13:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:13:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:13:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:13:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-19 16:13:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:13:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-19 16:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-19 16:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:14:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:14:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:14:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:15:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:15:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:15:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:15:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:15:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:15:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:15:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:16:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:16:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:17:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:17:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:17:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:19:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:19:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:19:10 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 16:19:10 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-19 16:19:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "hello"
INFO - 2015-08-19 16:19:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:19:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:21:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:21:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:21:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:22:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:22:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:22:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:39:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:39:59 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-19 16:39:59 --> Notice - Undefined variable: title in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 5
INFO - 2015-08-19 16:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:41:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:41:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:41:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:43:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:43:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:43:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:46:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-19 16:46:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:46:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:50:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:50:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:50:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:52:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:52:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:52:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:52:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:52:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:52:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:53:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:53:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:53:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:53:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:54:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:54:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:54:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 16:56:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 16:56:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 16:56:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:34:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:34:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:34:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/assets/img/clinics"
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:34:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/css/assets/img/clinic"
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:35:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/assets/img/clinic"
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:35:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:36:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:36:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:36:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:36:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:36:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:36:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:37:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:37:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:38:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:38:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:38:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:39:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:39:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:39:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:41:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:41:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:41:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:47:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:47:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:47:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:49:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:49:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:49:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:50:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:50:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:50:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:51:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:51:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:51:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:52:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:52:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:52:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:53:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:53:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:53:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:53:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:53:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:53:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:53:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:53:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:53:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:53:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:53:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:53:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:54:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:54:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:54:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:54:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:54:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:54:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:55:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:55:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:55:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:55:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:55:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:55:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:57:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:57:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:57:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:57:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:57:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:57:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:58:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 18:58:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 18:58:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 18:58:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:10:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:10:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:10:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:14:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:14:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:14:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:16:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:16:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:16:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:16:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:17:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:17:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:17:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:18:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:18:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:18:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:22:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:22:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:22:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:23:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:23:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:23:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:24:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:24:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:24:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:24:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:24:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:24:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:24:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:24:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:24:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:25:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:25:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:25:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:26:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:26:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:27:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:27:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:27:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:28:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:28:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:28:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:28:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:28:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:28:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:30:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:30:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:30:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:31:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:31:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:31:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:32:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:32:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:32:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:32:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:32:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:32:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:34:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:34:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:34:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:35:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:35:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:35:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:35:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:35:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:35:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:35:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:35:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:35:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 19:37:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 19:37:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 19:37:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:52:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:52:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:52:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:54:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-19 21:54:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:54:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:54:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-19 21:54:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:54:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:54:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-19 21:54:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:54:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:54:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-19 21:54:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:54:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:55:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:55:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:55:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:57:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:57:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:57:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:58:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:58:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:58:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 21:59:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 21:59:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 21:59:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:02:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:02:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:02:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:02:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:02:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:02:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:03:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-19 22:03:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:03:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:04:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:04:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:04:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:07:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:07:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:07:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:07:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:07:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:07:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:09:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:09:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:09:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:09:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:09:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:09:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:12:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:12:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:12:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:15:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:15:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:15:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:17:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:17:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:17:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:17:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:17:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:17:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:18:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:18:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:18:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:19:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:19:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:19:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:22:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:22:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:22:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:24:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:24:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:24:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:24:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:24:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:24:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:36:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:36:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:36:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:36:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:36:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:36:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:38:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:38:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:38:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:39:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:39:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:39:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:39:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 22:46:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 22:46:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 22:46:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 23:04:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-19 23:04:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 23:04:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 23:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-19 23:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 23:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 23:04:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-19 23:04:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 23:04:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-19 23:22:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-19 23:22:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-19 23:22:03 --> Fuel\Core\Request::execute - Setting main Request
