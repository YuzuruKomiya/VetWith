<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-25 14:20:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 14:20:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 14:20:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 14:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact/confirm"
INFO - 2015-08-25 14:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 14:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 14:21:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 14:21:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 14:21:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:30:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:30:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:30:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:30:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-25 15:30:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:30:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:30:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:30:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:30:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:34:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:34:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:34:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:34:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:34:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:34:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:58:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:58:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:58:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-25 15:58:11 --> Error - Could not find asset: chooseauth in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-08-25 15:58:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:58:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:58:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 15:59:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 15:59:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 15:59:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:04:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:04:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:04:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-25 16:04:11 --> Parsing Error - syntax error, unexpected ')' in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 19
INFO - 2015-08-25 16:04:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:04:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:04:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 16:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:12:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:12:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:12:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:13:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:13:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:13:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:13:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:13:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:13:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:14:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:14:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:14:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:14:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:14:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:14:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:20:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:20:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:20:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:21:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:21:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:21:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:21:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:21:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:21:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:21:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:21:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:21:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:21:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:21:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 16:21:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:21:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 16:22:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 16:22:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 16:22:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:34:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 20:34:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:34:41 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-25 20:34:41 --> Error - Could not find asset: chooseauth in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-08-25 20:35:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 20:35:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:35:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:36:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 20:36:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:36:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:36:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 20:36:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:36:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:36:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 20:36:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:36:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:36:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 20:36:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:36:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:38:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 20:38:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:38:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/clinic/auth/login"
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:38:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:38:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 20:38:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:38:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 20:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-25 20:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 20:58:08 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-25 20:58:09 --> Fatal Error - Call to undefined function json_safe_encode() in C:\Users\yuduru\work\fuelphp\fuel\app\views\parts\header.php on line 2
INFO - 2015-08-25 21:02:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-25 21:02:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/chooseauth"
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:02:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/chooseauth"
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:02:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/chooseauth"
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/chooseauth"
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/6"
INFO - 2015-08-25 21:03:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/apply/chooseauth"
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/chooseauth"
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:03:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/chooseauth"
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:04:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "chooseauth"
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:05:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "chooseauth"
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:06:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:06:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:06:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:06:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:06:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:06:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:06:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:08:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:08:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:08:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:09:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:09:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:09:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:09:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:09:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:09:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:10:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:10:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:10:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:10:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:10:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:10:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:11:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:11:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:11:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:11:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-25 21:11:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:11:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/delete"
INFO - 2015-08-25 21:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:11:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-25 21:11:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:11:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:26:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-25 21:26:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:26:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:27:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-25 21:27:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:27:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:27:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-25 21:27:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:27:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:28:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-25 21:28:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:28:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:29:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/invite"
INFO - 2015-08-25 21:29:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:29:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:29:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:29:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:29:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:29:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:29:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:29:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-25 21:32:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:32:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:32:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-25 21:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:32:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-25 21:32:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:32:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:33:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:33:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:33:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:33:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 21:33:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:33:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:33:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-25 21:33:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:33:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:33:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:33:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:33:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:37:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 21:37:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:37:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:37:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 21:37:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:37:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:37:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/invite"
INFO - 2015-08-25 21:37:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:37:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:37:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 21:37:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:37:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:37:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 21:37:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:37:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:40:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:40:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-25 21:41:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-25 21:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:41:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:41:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:41:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:45:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-25 21:45:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-25 21:45:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-25 21:45:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-25 21:45:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:45:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-25 21:45:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:45:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:46:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-25 21:46:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:46:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-25 21:54:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/report/2"
INFO - 2015-08-25 21:54:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-25 21:54:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:54:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-25 21:54:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-25 21:54:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:54:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-25 21:57:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 21:57:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-25 21:57:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 21:57:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-25 21:57:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 21:57:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 21:57:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 21:57:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:12:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 22:12:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:12:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:12:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-25 22:12:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:12:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 22:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-25 22:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 22:13:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 22:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "terms"
INFO - 2015-08-25 22:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "operation"
INFO - 2015-08-25 22:13:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "contact"
INFO - 2015-08-25 22:13:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-25 22:13:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-25 22:13:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-25 22:13:36 --> Fuel\Core\Request::execute - Setting main Request
