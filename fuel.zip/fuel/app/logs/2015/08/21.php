<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-21 00:06:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 00:06:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 00:06:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 00:06:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 00:06:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 00:06:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 00:06:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 00:06:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 00:06:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 00:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 00:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 00:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 00:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 00:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 00:13:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 15:59:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 15:59:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 15:59:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:07:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:07:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:07:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:16:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:16:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:16:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:26:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:26:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:26:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:47:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:47:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:47:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:47:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:47:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:47:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 16:48:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 16:48:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 16:48:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:22:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:22:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:22:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:24:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:24:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:24:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:25:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:25:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:25:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:26:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:26:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:26:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:26:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:26:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:26:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:26:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:26:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:26:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:26:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:26:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:26:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:26:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:26:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:26:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:27:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:27:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:27:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:27:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:27:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:27:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:27:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:27:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:27:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:27:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:27:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:27:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:28:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:28:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:28:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:28:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:28:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:28:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:28:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:28:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:28:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:28:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:29:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:29:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:29:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:29:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:29:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:29:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:29:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:29:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:29:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:36:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:36:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:36:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:36:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:36:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:36:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:36:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:36:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:36:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:38:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:38:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:38:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:40:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:40:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:40:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:40:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:40:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:40:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:42:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:42:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:42:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:43:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:43:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:43:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:44:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:44:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:44:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:44:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:44:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:44:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:44:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:44:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:44:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:47:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:47:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:47:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:48:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:48:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:48:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:49:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:49:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:49:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:50:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:50:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:50:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:52:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:52:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:52:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:52:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:52:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:52:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 17:59:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 17:59:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 17:59:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:04:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:04:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:04:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:06:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:06:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:06:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:11:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:11:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:11:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-21 18:11:19 --> Error - Could not find asset: top/doctor_s.png in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-08-21 18:11:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:11:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:11:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:15:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:15:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:15:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:15:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:15:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:15:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:16:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:16:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:16:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:17:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:17:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:17:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:17:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:17:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:17:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:17:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:17:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:17:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:18:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:18:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:18:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:19:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/top/c_vaerify"
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:19:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:19:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:19:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:19:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:30:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:30:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:30:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:31:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:31:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:31:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:31:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:31:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:31:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:31:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:31:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:31:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:32:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:32:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:32:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:39:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:39:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:39:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:39:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:39:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:39:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:42:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:42:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:42:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:55:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:55:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:55:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:55:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:55:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:55:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 18:56:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 18:56:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 18:56:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:00:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:00:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:00:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:01:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:01:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:01:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:01:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:01:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:01:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:01:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:01:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:01:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:03:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:03:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:03:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:03:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:03:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:03:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:08:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:08:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:08:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:10:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:10:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:10:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:10:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:11:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:11:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:11:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:11:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:12:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:12:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:12:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:12:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:12:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:12:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:12:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:12:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:13:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:13:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:13:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:21:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:22:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:22:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:22:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:23:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:23:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:23:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:24:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:24:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:24:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "assets/img/top/dog"
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:25:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:25:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:25:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:30:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:30:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:30:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:43:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:43:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:43:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:43:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:43:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:43:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:44:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:44:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:44:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:44:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:44:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:44:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:45:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:45:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:45:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:45:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:45:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:45:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:46:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:46:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:46:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:47:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:47:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:47:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:47:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:47:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:47:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 19:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 19:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 19:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:08:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-21 20:08:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:08:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:08:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-21 20:08:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:08:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:12:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:12:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:12:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:12:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:12:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:12:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:12:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:12:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:12:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:12:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:12:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:12:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:13:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:13:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:13:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:19:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:19:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:19:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:20:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:20:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:20:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:22:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:22:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:22:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:22:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:22:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:22:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:22:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:22:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:22:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:22:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:22:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:22:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:32:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:32:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:32:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:32:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:32:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:32:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:32:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:32:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:32:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:35:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:35:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:35:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:36:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:36:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:36:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:37:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:37:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:37:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:37:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:37:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:37:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:37:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:37:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:37:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:38:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:38:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:38:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:38:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:38:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:38:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:38:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:38:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:38:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:39:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:39:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:39:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:39:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:39:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:39:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:39:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:39:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:39:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:39:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:39:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:40:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:40:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:40:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:40:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:40:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:40:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:40:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:40:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:40:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:40:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:40:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:40:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:41:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:41:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:41:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:41:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:41:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:41:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:41:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:42:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:42:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:42:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:43:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:43:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:43:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:44:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:44:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:44:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:44:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:44:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:44:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:44:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:44:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:44:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:44:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:45:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:45:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:45:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:46:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:46:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:46:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:47:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:47:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:47:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:54:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:54:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:54:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:55:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:55:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:55:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:55:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:55:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:55:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:56:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:56:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:56:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:59:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:59:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:59:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:59:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:59:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:59:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:59:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:59:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:59:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 20:59:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 20:59:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 20:59:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:00:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:00:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:00:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:02:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:02:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:02:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:02:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:02:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:02:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:03:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:03:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:03:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:03:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:03:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:03:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:03:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:03:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:03:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:04:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:04:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:04:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:04:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:04:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:04:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:05:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:05:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:05:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:09:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:09:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:09:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:10:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:10:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:10:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:12:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:12:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:12:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:13:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:13:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:13:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:17:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:17:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:17:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:17:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:17:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:17:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:19:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:19:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:19:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:26:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:26:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:26:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:28:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:28:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:28:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:28:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:28:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:28:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:28:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:28:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:28:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:29:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:29:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:29:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:30:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:30:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:30:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:34:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:34:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:34:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:34:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:34:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:34:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:35:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:35:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:35:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:35:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:41:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:41:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:41:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:41:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:41:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:41:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:42:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:42:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:42:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:43:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:43:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:43:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:45:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:45:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:45:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:45:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:45:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:45:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:45:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:45:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:45:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:46:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:46:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:46:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:46:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:46:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:46:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:47:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:47:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:47:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:48:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:48:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:48:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:48:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:48:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:48:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-21 21:55:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-21 21:55:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-21 21:55:41 --> Fuel\Core\Request::execute - Setting main Request
