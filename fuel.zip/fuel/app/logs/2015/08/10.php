<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-10 13:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 13:52:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:52:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:52:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 13:54:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:54:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:54:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 13:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 13:55:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:55:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:55:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 13:56:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 13:56:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 13:56:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:02:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:02:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:02:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:05:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:05:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:05:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:06:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:06:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:06:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:06:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:06:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:06:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:07:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:07:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:07:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:07:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:07:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:07:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:11:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:11:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:11:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:12:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:12:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:12:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:47:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:47:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:47:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 14:47:42 --> Notice - Undefined variable: profile in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\offer.php on line 6
INFO - 2015-08-10 14:48:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:48:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:48:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:50:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:50:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:50:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:55:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:55:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:55:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 14:55:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 14:55:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 14:55:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 15:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-10 15:24:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 15:24:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 15:24:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 15:24:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 15:24:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 21:04:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 21:04:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 21:04:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 21:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 21:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 21:08:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 21:16:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 21:16:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 21:16:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 21:17:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 21:17:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 21:17:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:18:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:18:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:18:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:19:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:19:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:19:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:19:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:19:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:19:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:20:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:20:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:20:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:20:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
INFO - 2015-08-10 23:20:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:20:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:21:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
INFO - 2015-08-10 23:21:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:21:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:21:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:21:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:21:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:21:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:21:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:21:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:21:56 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 30
INFO - 2015-08-10 23:30:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:30:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:30:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:30:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
ERROR - 2015-08-10 23:30:28 --> Notice - Use of undefined constant On - assumed 'On' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 2
INFO - 2015-08-10 23:31:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
ERROR - 2015-08-10 23:31:04 --> Notice - Use of undefined constant On - assumed 'On' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 2
INFO - 2015-08-10 23:31:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
INFO - 2015-08-10 23:31:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:31:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:31:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/post_add"
INFO - 2015-08-10 23:31:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:31:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:31:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:31:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:31:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:31:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:31:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:31:39 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:31:39 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 30
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:34:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:34:08 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 31
INFO - 2015-08-10 23:37:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:37:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:37:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:37:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:37:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:37:52 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:37:52 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 31
INFO - 2015-08-10 23:40:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:40:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:40:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:40:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:40:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:40:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:40:56 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 29
INFO - 2015-08-10 23:42:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:42:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:42:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:42:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:42:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:42:35 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:42:36 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 29
INFO - 2015-08-10 23:42:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:42:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:42:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:42:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:42:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:42:42 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:42:42 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 29
INFO - 2015-08-10 23:43:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:43:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:43:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:44:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:44:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:44:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:44:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:44:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:44:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:44:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:44:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:44:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:44:45 --> Notice - Undefined variable: offe_id in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 29
INFO - 2015-08-10 23:46:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/logout"
INFO - 2015-08-10 23:46:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:46:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:46:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:46:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:46:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:46:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:46:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:46:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/studentauth/login"
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:51:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:51:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:51:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:51:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-10 23:51:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-10 23:51:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-10 23:51:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:51:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/add"
INFO - 2015-08-10 23:51:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:51:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:51:50 --> 1048 - Column 'offer_id' cannot be null [ INSERT INTO `bookmarks` (`s_username`, `offer_id`) VALUES ('aaaaaaaa', null) ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-10 23:56:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:56:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:56:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:56:55 --> Notice - Undefined variable: auth in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 7
INFO - 2015-08-10 23:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:57:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:57:15 --> Notice - Undefined variable: auth in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\bookmark.php on line 7
INFO - 2015-08-10 23:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:57:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:57:22 --> Notice - Undefined variable: header in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 39
INFO - 2015-08-10 23:57:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:57:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:57:56 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:57:56 --> Notice - Undefined variable: test in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 3
INFO - 2015-08-10 23:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:58:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:58:06 --> Notice - Undefined variable: test in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 3
INFO - 2015-08-10 23:58:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:58:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:58:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:58:09 --> Notice - Undefined variable: test in C:\Users\yuduru\work\fuelphp\fuel\app\views\test.php on line 3
INFO - 2015-08-10 23:58:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:58:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:58:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-10 23:58:30 --> Notice - Undefined variable: footer in C:\Users\yuduru\work\fuelphp\fuel\app\views\template.php on line 51
INFO - 2015-08-10 23:58:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:58:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:58:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-10 23:59:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark"
INFO - 2015-08-10 23:59:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-10 23:59:39 --> Fuel\Core\Request::execute - Setting main Request
