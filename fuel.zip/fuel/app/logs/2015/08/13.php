<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:09:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-13 18:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-13 18:10:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:10:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-13 18:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-13 18:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-13 18:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:11:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 18:11:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:11:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:11:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 18:11:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:11:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:11:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-13 18:11:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:11:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:11:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:12:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:12:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:12:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:12:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:12:07 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-13 18:13:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 18:13:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 18:13:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 18:13:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 18:13:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_confirm"
INFO - 2015-08-13 18:13:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:13:38 --> Notice - Undefined variable: offer_form in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\offer_register.php on line 24
INFO - 2015-08-13 18:13:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_completion"
INFO - 2015-08-13 18:13:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:13:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:13:56 --> Fuel\Core\Request::__construct - Creating a new HMVC Request with URI = "error/invalid"
INFO - 2015-08-13 18:13:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:21:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:21:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:21:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:21:18 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-13 18:21:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 18:21:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:21:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 18:21:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:21:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:21:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:21:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:21:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:21:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:21:29 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-13 18:41:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:41:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:41:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:41:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:41:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:41:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:41:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:41:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:41:51 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:41:51 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-13 18:41:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:41:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:41:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:42:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 18:42:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:42:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:42:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:42:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 18:42:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:42:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:42:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:42:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:46:07 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:46:07 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:46:07 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-13 18:46:07 --> Notice - Undefined variable: bookmark_array in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\check_offer.php on line 3
INFO - 2015-08-13 18:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage/bookmark"
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-13 18:51:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-13 18:51:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:51:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/mypage"
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "student/auth/login"
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:51:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:53:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:53:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:53:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 18:54:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 18:54:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 18:54:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:05:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:05:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:05:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:05:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:06:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:06:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:06:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "bookmark/precheck"
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:06:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:07:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:07:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:07:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:21:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:21:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:21:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:22:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:22:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:22:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:22:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:22:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:22:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:33:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:33:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:33:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:34:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:34:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:34:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:35:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:35:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:35:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:37:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 19:39:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:39:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:39:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:39:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:40:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:01 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:40:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:40:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:40:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:41:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:41:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:41:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:41:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:41:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:41:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:41:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:41:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 19:41:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:41:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 19:41:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:41:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:42:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:42:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:42:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 19:43:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 19:43:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 19:43:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:38:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 22:38:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:38:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-13 22:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:38:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 22:38:39 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:38:39 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 22:43:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 22:43:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 22:43:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 22:43:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-13 22:43:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 22:43:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:00:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:00:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:00:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:02:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:02:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:02:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:03:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:03:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:03:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:04:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:04:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:04:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:04:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:04:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:04:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:05:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:05:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:05:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:06:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:06:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:06:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:07:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:07:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:07:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:07:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:07:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:07:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:09:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:09:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:09:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:10:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:10:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:10:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:10:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:10:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:10:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:10:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:10:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:10:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:11:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:11:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:11:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:12:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:12:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:12:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:34:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:34:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:34:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:34:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:34:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:34:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:34:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:34:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:34:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:34:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:35:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:35:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:35:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:35:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:35:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:35:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:36:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:36:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:36:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:36:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:36:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:36:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:36:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:36:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:36:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:40:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:40:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:40:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:42:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:42:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:42:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:44:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
ERROR - 2015-08-13 23:44:28 --> Compile Error - Cannot use isset() on the result of a function call (you can use "null !== func()" instead) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 861
INFO - 2015-08-13 23:45:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:03 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-13 23:45:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:45:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:19 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:19 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-13 23:58:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-13 23:58:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-13 23:58:26 --> Fuel\Core\Request::execute - Setting main Request
