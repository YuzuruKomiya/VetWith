<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-07 13:29:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:29:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:29:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:29:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 13:29:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:29:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:29:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 13:29:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:29:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:29:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-07 13:29:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:29:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:29:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 13:29:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:29:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:30:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 13:30:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:30:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:30:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:30:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:30:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/mypage/upload_images_completion"
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:30:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:32:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinics/mypage/upload_images_completion"
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinics/mypage/upload_images_completion"
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:32:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:32:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:32:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:32:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 13:32:27 --> Notice - Undefined index: message in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 730
INFO - 2015-08-07 13:37:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:37:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:37:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:37:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:37:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:37:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 13:37:47 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\upload_images_error.php on line 5
INFO - 2015-08-07 13:38:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:38:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:38:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:38:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:38:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:38:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 13:38:18 --> Fatal Error - Call to undefined function select() in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 143
INFO - 2015-08-07 13:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:39:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:39:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:39:00 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 13:39:00 --> Warning - Illegal string offset 'field' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 162
INFO - 2015-08-07 13:42:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 13:42:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:42:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 13:42:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 13:42:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 13:42:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:00:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:00:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:00:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:01:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:01:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:01:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:01:05 --> Warning - Illegal string offset 'field' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 162
INFO - 2015-08-07 14:01:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:01:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:01:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:01:20 --> Warning - Illegal string offset 'field' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 162
INFO - 2015-08-07 14:03:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:03:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:03:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:03:17 --> Notice - Undefined index: field in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 154
INFO - 2015-08-07 14:03:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:03:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:03:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:03:38 --> Warning - Illegal string offset 'field' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 162
INFO - 2015-08-07 14:04:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:04:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:04:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:04:03 --> Warning - Illegal string offset 'field' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 162
INFO - 2015-08-07 14:06:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:06:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:06:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:10:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:10:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:10:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:10:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:10:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:10:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:13:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:13:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:13:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:13:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:13:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:13:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:46:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:46:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:46:48 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:46:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:46:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:46:50 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:46:50 --> Notice - Undefined index: message in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 744
INFO - 2015-08-07 14:47:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:47:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:47:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:47:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:47:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:47:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:47:15 --> Notice - Undefined index: message in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 744
INFO - 2015-08-07 14:48:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:48:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:48:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:48:27 --> Notice - Undefined offset: 0 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 744
INFO - 2015-08-07 14:48:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:48:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:48:37 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:48:37 --> Notice - Undefined index: errors in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 744
INFO - 2015-08-07 14:49:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 14:49:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:49:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:49:48 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:49:48 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:49:48 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:49:48 --> Notice - Undefined index: errors in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 746
INFO - 2015-08-07 14:50:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:50:03 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:50:03 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:50:03 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 746
INFO - 2015-08-07 14:50:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:50:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:50:13 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 14:50:13 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 746
INFO - 2015-08-07 14:50:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:50:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:50:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 14:51:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 14:51:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 14:51:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:04:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 15:04:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:04:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:04:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 15:04:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:04:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:04:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:04:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:04:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 15:04:47 --> Notice - Undefined variable: error_message in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 746
INFO - 2015-08-07 15:05:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:05:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:05:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 15:05:28 --> Notice - Array to string conversion in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 747
INFO - 2015-08-07 15:06:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:06:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:06:04 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 15:06:04 --> Warning - Illegal string offset 'message' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 747
INFO - 2015-08-07 15:07:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
ERROR - 2015-08-07 15:07:20 --> Parsing Error - syntax error, unexpected 'if' (T_IF) in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 744
INFO - 2015-08-07 15:07:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:07:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:07:28 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 15:07:28 --> Warning - Illegal string offset 'message' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 749
INFO - 2015-08-07 15:07:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:07:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:07:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:08:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:08:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:08:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 15:08:17 --> Notice - Use of undefined constant errors - assumed 'errors' in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 746
INFO - 2015-08-07 15:08:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:08:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:08:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:09:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:09:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:09:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:09:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:09:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:09:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 15:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:10:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 15:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 15:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 15:10:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:38:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:38:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 17:38:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:38:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:38:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-07 17:38:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:38:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:38:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 17:38:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:38:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:39:01 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:39:01 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:39:01 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 17:39:02 --> Error - データベースエラーです。 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\model\clinic\mypage.php on line 176
INFO - 2015-08-07 17:48:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:48:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:48:55 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 17:48:55 --> Error - Cannot delete file: given path "C:\Users\yuduru\work\fuelphp\public\assets\img\c_image" is not a file. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\file.php on line 620
INFO - 2015-08-07 17:49:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:49:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:49:24 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 17:49:25 --> Error - Cannot delete file: given path "C:\Users\yuduru\work\fuelphp\public\assets\img\0a909cb3c502f4a4d3fa2bf243924037.gif" is not a file. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\file.php on line 620
INFO - 2015-08-07 17:59:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 17:59:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:59:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:59:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:59:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 17:59:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:59:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:59:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:59:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 17:59:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 17:59:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 17:59:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 17:59:21 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 17:59:21 --> Error - Cannot delete file: given path "C:\Users\yuduru\work\fuelphp\public\assets\img\a44261622115555484978cb1cfd12d50.gif" is not a file. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\file.php on line 620
INFO - 2015-08-07 18:00:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:00:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:00:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:00:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:00:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:00:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:00:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:00:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:00:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:00:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:00:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:00:34 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:00:34 --> Error - Cannot delete file: given path "C:\Users\yuduru\work\fuelphp\public\assets\img\clinics\16d0f5b8dcbc350f564abea72ef34491.gif" is not a file. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\file.php on line 620
INFO - 2015-08-07 18:01:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:01:10 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:01:10 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:01:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:01:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:01:15 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:01:15 --> Error - Cannot delete file: given path "C:\Users\yuduru\work\fuelphp\public\assets\img\clinics\9748895d74041e23b72dc8a68e0b10c2.gif" is not a file. in C:\Users\yuduru\work\fuelphp\fuel\core\classes\file.php on line 620
INFO - 2015-08-07 18:02:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:02:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:02:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:02:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:02:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:02:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:02:11 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 755
INFO - 2015-08-07 18:04:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:04:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:04:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:04:18 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:04:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:04:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:04:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:04:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:04:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:04:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:04:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:04:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:04:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:05:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:05:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:05:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:05:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:05:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:05:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:05:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:05:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:05:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:05:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:05:29 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 755
INFO - 2015-08-07 18:06:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:06:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:06:45 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:06:45 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 757
INFO - 2015-08-07 18:06:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:06:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:06:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:06:51 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:06:51 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:06:51 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:10:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:10:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:10:17 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:10:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:10:18 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:10:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 18:10:19 --> Notice - Undefined index: message in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 748
INFO - 2015-08-07 18:13:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:13:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:13:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:13:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:13:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:13:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:13:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:13:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:13:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:13:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:13:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:13:16 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:24:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:24:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:24:46 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:24:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:24:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:24:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:25:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 18:25:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:25:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 18:25:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 18:25:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 18:25:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 19:03:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 19:03:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 19:03:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:28:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:28:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:28:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:28:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 22:28:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:28:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-07 22:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:28:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-07 22:28:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:28:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:28:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:28:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:28:36 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 22:28:36 --> Notice - Undefined variable: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\upload_images.php on line 40
INFO - 2015-08-07 22:29:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:29:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:29:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 22:29:12 --> Notice - Undefined offset: 1 in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\clinic\mypage.php on line 708
INFO - 2015-08-07 22:30:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:30:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:30:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 22:30:20 --> Error - Could not find asset: clinics/ in C:\Users\yuduru\work\fuelphp\fuel\core\classes\asset\instance.php on line 261
INFO - 2015-08-07 22:33:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:33:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:33:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:33:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:33:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:33:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:35:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:35:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:35:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:35:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:35:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:35:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:46:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images_completion"
INFO - 2015-08-07 22:46:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:46:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:47:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:47:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:47:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:50:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:50:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:50:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:51:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:51:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:51:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:51:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:51:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:51:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:52:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:52:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:52:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:52:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:52:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:52:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:57:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:57:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:57:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:57:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 22:57:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:57:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:57:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:57:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:57:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:57:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 22:57:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:57:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 22:57:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 22:57:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 22:57:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:03:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:03:16 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:03:16 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:03:16 --> 1241 - Operand should contain 1 column(s) [ SELECT * FROM `c_images` WHERE `c_username` = ('5', 'aaaaaaaa', 'まみむ', 'あぽー！', 'あいう', 'えお', 'かきく', 'けこ', 'さしす\r\nせｓｐ', 'たちつ', 'てと', 'なにぬ', 'ねの') ] in C:\Users\yuduru\work\fuelphp\fuel\core\classes\database\mysqli\connection.php on line 290
INFO - 2015-08-07 23:03:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:03:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:03:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:04:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:04:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:04:26 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:04:26 --> Notice - Undefined variable: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\offer.php on line 24
INFO - 2015-08-07 23:06:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:06:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:06:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:06:05 --> Notice - Undefined variable: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\offer.php on line 24
INFO - 2015-08-07 23:06:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:06:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:06:20 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:06:20 --> Notice - Undefined variable: r_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\offer.php on line 38
INFO - 2015-08-07 23:06:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:06:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:06:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:08:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:08:27 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:08:27 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:08:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:08:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:08:38 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:08:38 --> Notice - Undefined index: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\classes\controller\offers.php on line 40
INFO - 2015-08-07 23:09:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:09:11 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:09:11 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:10:00 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:10:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:10:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:10:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:10:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-07 23:10:42 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:10:42 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:15:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-07 23:15:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:15:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:20:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:20:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:20:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:20:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:20:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:20:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:20:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:21:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:21:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:21:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:21:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:21:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:21:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:21:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:21:47 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:21:47 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:21:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-07 23:21:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:21:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:28:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:28:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:28:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:28:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:28:41 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:28:41 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:28:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:28:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:28:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:29:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/5"
INFO - 2015-08-07 23:29:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:29:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/index/6"
INFO - 2015-08-07 23:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:30:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:30:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:30:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:31:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:31:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:31:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:32:17 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:32:17 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:32:17 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:32:17 --> Notice - Undefined variable: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\search.php on line 31
INFO - 2015-08-07 23:32:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:32:46 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:32:46 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-07 23:32:46 --> Notice - Undefined index: c_image in C:\Users\yuduru\work\fuelphp\fuel\app\views\offers\search.php on line 31
INFO - 2015-08-07 23:33:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:33:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:33:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:33:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:33:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:33:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:38:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/search"
INFO - 2015-08-07 23:38:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:38:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:44:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/5"
INFO - 2015-08-07 23:44:05 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:44:05 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:45:15 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-07 23:45:15 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:45:15 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:49:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-07 23:49:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:49:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/６"
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "welcome/404"
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:49:36 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:49:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "offers/6"
INFO - 2015-08-07 23:49:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:49:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = ""
INFO - 2015-08-07 23:54:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-07 23:54:26 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:26 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-07 23:54:28 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:28 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-07 23:54:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:32 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:32 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:43 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:43 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 23:54:45 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:45 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:49 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:49 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:49 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:50 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:53 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:54 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:54 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 23:54:55 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:55 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-07 23:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-07 23:54:57 --> Fuel\Core\Request::execute - Setting main Request
