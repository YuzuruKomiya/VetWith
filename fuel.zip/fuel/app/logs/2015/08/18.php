<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

INFO - 2015-08-18 19:16:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-18 19:16:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 19:16:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 19:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/auth/login"
INFO - 2015-08-18 19:16:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 19:16:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 19:16:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-18 19:16:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 19:16:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 19:16:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 19:16:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 19:16:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:34:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 20:34:13 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:34:13 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:43:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 20:43:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:43:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:47:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 20:47:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:47:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:55:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 20:55:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:55:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:55:25 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 20:55:25 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:55:25 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:55:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 20:55:56 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:55:56 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:56:04 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 20:56:04 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:56:04 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 20:56:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 20:56:44 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 20:56:44 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:28:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 21:28:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:28:31 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:28:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:28:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:28:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:29:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:29:58 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:29:58 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:30:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:30:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:30:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:30:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:30:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:30:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:30:59 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:30:59 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:30:59 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:37:02 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 21:37:02 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:37:02 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:37:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 21:37:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:37:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:38:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:38:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:38:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:39:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:39:31 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:39:31 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-18 21:39:32 --> Notice - Undefined variable: apply in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 94
INFO - 2015-08-18 21:39:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:39:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:39:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:41:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:41:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:41:14 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2015-08-18 21:41:14 --> Notice - Undefined variable: apply in C:\Users\yuduru\work\fuelphp\fuel\app\views\clinic\mypage\apply_detail.php on line 23
INFO - 2015-08-18 21:41:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:41:20 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:41:20 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:41:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 21:41:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:41:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 21:44:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 21:44:52 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 21:44:52 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:38:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:38:30 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:38:30 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:38:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:38:33 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:38:33 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:38:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:38:38 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:38:38 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:38:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:38:40 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:38:40 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:39:06 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:06 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:08 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-18 22:39:08 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:08 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:39:09 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:09 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:39:12 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:12 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:39:14 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:14 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage"
INFO - 2015-08-18 22:39:21 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:21 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/set_detail"
INFO - 2015-08-18 22:39:22 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:22 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/offer_register"
INFO - 2015-08-18 22:39:23 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:23 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/upload_images"
INFO - 2015-08-18 22:39:24 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:24 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:39:29 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:29 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_apply"
INFO - 2015-08-18 22:39:35 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:35 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:39:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/apply_detail/2"
INFO - 2015-08-18 22:39:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:39:37 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:49:34 --> Fuel\Core\Request::execute - Setting main Request
INFO - 2015-08-18 22:49:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "clinic/mypage/check_offer"
INFO - 2015-08-18 22:49:37 --> Fuel\Core\Request::execute - Called
INFO - 2015-08-18 22:49:37 --> Fuel\Core\Request::execute - Setting main Request
