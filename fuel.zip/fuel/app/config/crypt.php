<?php
return array (
  'crypto_key' => 'k7snMYWPwNNwA9Qd90jvAVgQ',
  'crypto_iv' => 'oZUYOo4Wovr4efcPbo2IUG-A',
  'crypto_hmac' => 'siwxos3iQHlkIJgLN4JBMWHE',
);
