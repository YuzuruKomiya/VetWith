<?php
return array(
	'active' => 'default',
	'fallback' => 'default',
	'paths' => array(
	APPPATH.'themes',
	),
	'assets_folder' => 'assets',
	'view_ext' => '.php',
	'require_info_file' => false,
	'info_file_name' => 'themeinfo.php',
);